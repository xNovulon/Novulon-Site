@echo off
title Novulon's Lag Remover
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0lag_remover.ps1" apply
echo.
pause
