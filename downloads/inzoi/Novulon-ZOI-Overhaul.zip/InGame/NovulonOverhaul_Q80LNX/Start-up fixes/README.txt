Novulon's ZOI Overhaul: start-up fixes (optional)
===================================================

The Overhaul's Performance tab already makes the game run smoother while you play.
These two small settings also help during loading screens, so fewer things freeze
the first time they show up. Nothing here lowers your graphics.

How to use
----------
1. Close inZOI.
2. Double-click "Apply start-up fixes.cmd" once.
   "Undo start-up fixes.cmd" puts the game's settings file back exactly as it was.
Both only work while the game is closed, because the game rewrites that file when it closes.

Also helps
----------
- Laptops: keep the charger plugged in while playing.
- Windows: Settings > System > Power & battery > Power mode > Best performance.
- Keep your PC cool. A hot laptop slows itself down, and that feels like lag.
- NVIDIA: Control Panel > Manage 3D settings > Shader Cache Size > 10 GB.