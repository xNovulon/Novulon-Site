/**
 * view.js -- input plumbing for a UI mod view that is mostly invisible.
 * Only the element passed to lr.view.track() takes mouse input; everywhere else the game keeps it.
 * (Same rules as the scaffold's window.js: hover flag, content rect, click synthesized on mouseup.)
 */
(function () {
    'use strict';

    var tracked = null;

    function setHover(over) {
        try { if (window.inzoi && inzoi.view && inzoi.view.hover) { inzoi.view.hover(!!over); return; } } catch (e) {}
        try {
            if (typeof engine !== 'undefined') {
                engine.call('_uimod_request', JSON.stringify({ type: 'view', action: 'hover', over: !!over, promiseId: 0 }));
            }
        } catch (e) {}
    }

    // Tell the game which part of the screen belongs to this view (nothing when hidden).
    function report() {
        var x = 0, y = 0, w = 0, h = 0;
        if (tracked && tracked.offsetWidth) {
            var r = tracked.getBoundingClientRect();
            x = Math.round(r.left); y = Math.round(r.top); w = Math.round(r.width); h = Math.round(r.height);
        }
        try { if (window.inzoi && inzoi.view && inzoi.view.setContentRect) { inzoi.view.setContentRect(x, y, w, h); } } catch (e) {}
        if (!w) { setHover(false); }
    }

    function track(elm) {
        tracked = elm;
        report();
    }

    function bind(elm) {
        elm.addEventListener('mouseenter', function () { setHover(true); });
        elm.addEventListener('mouseleave', function () { setHover(false); });
        elm.addEventListener('wheel', function (e) { e.stopPropagation(); }, { passive: false });

        // cohtml sometimes drops the native click; build one from mousedown + mouseup on the same target.
        var down = null, guard = false;
        elm.addEventListener('mousedown', function (e) { down = e.target; }, true);
        elm.addEventListener('mouseup', function (e) {
            var d = down; down = null;
            if (!d) { return; }
            var up = e.target;
            if (!(up === d || (d.contains && d.contains(up)) || (up.contains && up.contains(d)))) { return; }
            guard = true;
            var evt;
            try { evt = new MouseEvent('click', { bubbles: true, cancelable: true }); }
            catch (err) { evt = document.createEvent('MouseEvents'); evt.initEvent('click', true, true); }
            evt._synthetic = true;
            up.dispatchEvent(evt);
            setTimeout(function () { guard = false; }, 0);
        }, true);
        elm.addEventListener('click', function (e) {
            if (e._synthetic) { return; }
            if (guard) { e.stopImmediatePropagation(); e.preventDefault(); }
        }, true);
    }

    function cli(cmd, params) { return inzoi.cli.execute(cmd, params || {}); }

    // Command result -> data (the game sometimes sends a text line before the JSON).
    function run(cmd, params) {
        return Promise.resolve(cli(cmd, params)).then(function (res) {
            if (res == null) { throw new Error(cmd + ': no answer'); }
            if (res.success === false) { throw new Error(String(res.message || cmd + ' failed')); }
            var d = res.data;
            if (typeof d === 'string') { d = loose(d); }
            if (d == null && typeof res.message === 'string') { d = loose(res.message); }
            if (d == null) { d = res.message != null ? res.message : res; }
            return d;
        });
    }
    function loose(text) {
        if (typeof text !== 'string') { return text; }
        try { return JSON.parse(text); } catch (e) {}
        var i = text.search(/[\[{]/);
        if (i > 0) { try { return JSON.parse(text.slice(i)); } catch (e2) {} }
        return null;
    }

    window.addEventListener('resize', function () { report(); });

    window.lr = window.lr || {};
    window.lr.view = { track: track, bind: bind, report: report, setHover: setHover };
    window.lr.cli = cli;
    window.lr.run = run;
})();
