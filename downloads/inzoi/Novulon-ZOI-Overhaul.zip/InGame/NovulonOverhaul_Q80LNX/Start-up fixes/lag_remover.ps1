# Novulon's ZOI Overhaul: the start-up fixes.
# The Overhaul's Performance tab applies the in-game fixes once you are in the world.
# These Engine.ini lines make the same engine fixes count from the first loading screen, which is when most
# shaders and textures load. Nothing here lowers quality.
#   lag_remover.ps1 apply   - add the fixes (remembers the old values first)
#   lag_remover.ps1 undo    - put the old values back, byte for byte
#   lag_remover.ps1 status  - show what is set now
param(
    [ValidateSet('apply', 'undo', 'status')][string]$Action = 'status',
    [string]$ConfigDir = (Join-Path $env:LOCALAPPDATA 'BlueClient\Saved\Config\Windows'),
    [string]$BackupDir = (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'Backup'),
    [switch]$NoGameCheck  # tests only: they work on copies, so a running game can't overwrite them
)
$ErrorActionPreference = 'Stop'

$Cfg = $ConfigDir
$Saved = $BackupDir
$PrevFile = Join-Path $Saved 'previous.json'

# Checked live against the running game (2026-09-28, build 20260915): these were off, and they only matter at load
# time, which is before the in-game mod starts. r.PSOPrecaching, r.PSOPrecache.ProxyCreationWhenPSOReady,
# r.ShaderPipelineCache.Enabled and s.AsyncLoadingThreadEnabled are already on in this build, so they are left alone.
# The texture pool is not set here on purpose: an Engine.ini value would override a bigger pool the game picks on
# higher texture settings. The in-game mod raises it to at least 2,000 MB instead, never lowering it.
$EngineFixes = [ordered]@{
    'SystemSettings' = [ordered]@{
        'r.CreateShadersOnLoad'   = '1'  # create shaders while loading, not the first time something is drawn
        'r.PSOPrecache.Resources' = '1'  # also precompile pipelines for resources, not only meshes
    }
}

function Test-GameRunning {
    [bool](Get-Process -Name 'inZOI-Win64-Shipping', 'inZOI' -ErrorAction SilentlyContinue)
}

function Read-Ini([string]$path) {
    $list = New-Object 'System.Collections.Generic.List[string]'
    if (Test-Path $path) { $list.AddRange([IO.File]::ReadAllLines($path)) }
    else { $list.Add(';METADATA=(Diff=true, UseCommands=true)') }
    , $list  # the comma keeps PowerShell from unrolling the list into a fixed-size array
}

function Write-Ini([string]$path, $lines) {
    [IO.File]::WriteAllText($path, (($lines -join "`r`n") + "`r`n"), (New-Object System.Text.UTF8Encoding($false)))
}

# Returns @{head; end} line indexes of a section (header line, first line after its body), or $null.
function Find-Section($lines, [string]$section) {
    $head = '[' + $section + ']'
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i].Trim() -eq $head) {
            $j = $i + 1
            while ($j -lt $lines.Count -and -not $lines[$j].Trim().StartsWith('[')) { $j++ }
            return @{ head = $i; end = $j }
        }
    }
    $null
}

function Get-IniValue($lines, [string]$section, [string]$key) {
    $s = Find-Section $lines $section
    if (-not $s) { return $null }
    for ($i = $s.head + 1; $i -lt $s.end; $i++) {
        if ($lines[$i] -match ('^\s*' + [regex]::Escape($key) + '\s*=(.*)$')) { return $Matches[1] }
    }
    $null
}

function Set-IniValue($lines, [string]$section, [string]$key, $value) {
    $s = Find-Section $lines $section
    if (-not $s) {
        if ($null -eq $value) { return }
        if ($lines.Count -and $lines[$lines.Count - 1].Trim() -ne '') { $lines.Add('') }
        $lines.Add('[' + $section + ']')
        $lines.Add("$key=$value")
        return
    }
    for ($i = $s.head + 1; $i -lt $s.end; $i++) {
        if ($lines[$i] -match ('^\s*' + [regex]::Escape($key) + '\s*=')) {
            if ($null -eq $value) { $lines.RemoveAt($i) } else { $lines[$i] = "$key=$value" }
            return
        }
    }
    if ($null -eq $value) { return }
    $at = $s.end
    while ($at -gt $s.head + 1 -and $lines[$at - 1].Trim() -eq '') { $at-- }
    $lines.Insert($at, "$key=$value")
}

$EnginePath = Join-Path $Cfg 'Engine.ini'

function Show-Status {
    $lines = Read-Ini $EnginePath
    foreach ($section in $EngineFixes.Keys) {
        foreach ($key in $EngineFixes[$section].Keys) {
            $now = Get-IniValue $lines $section $key
            $mark = if ($now -eq $EngineFixes[$section][$key]) { 'on ' } else { 'off' }
            '{0}  {1} = {2}' -f $mark, $key, ($(if ($null -eq $now) { '(game default)' } else { $now }))
        }
    }
}

if ($Action -eq 'status') { Show-Status; exit 0 }

if (-not $NoGameCheck -and (Test-GameRunning)) {
    Write-Host 'inZOI is open. Close the game first, then run this again (the game rewrites this file when it closes).'
    exit 1
}

$lines = Read-Ini $EnginePath

if ($Action -eq 'apply') {
    New-Item -ItemType Directory -Force $Saved | Out-Null
    # an untouched copy from the very first run, kept as a last resort
    $first = Join-Path $Saved 'original Engine.ini'
    if ((Test-Path $EnginePath) -and -not (Test-Path $first)) { Copy-Item $EnginePath $first }
    $previous = [ordered]@{}
    if (Test-Path $PrevFile) { (Get-Content $PrevFile -Raw | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $previous[$_.Name] = $_.Value } }
    foreach ($section in $EngineFixes.Keys) {
        foreach ($key in $EngineFixes[$section].Keys) {
            $id = "$section|$key"
            if (-not $previous.Contains($id)) { $previous[$id] = Get-IniValue $lines $section $key }
            Set-IniValue $lines $section $key $EngineFixes[$section][$key]
        }
    }
    Write-Ini $EnginePath $lines
    [IO.File]::WriteAllText($PrevFile, ($previous | ConvertTo-Json), (New-Object System.Text.UTF8Encoding($false)))
    Write-Host "The Overhaul's start-up fixes are on."
    Show-Status
    exit 0
}

if ($Action -eq 'undo') {
    if (-not (Test-Path $PrevFile)) { Write-Host 'Nothing to undo.'; exit 0 }
    $previous = Get-Content $PrevFile -Raw | ConvertFrom-Json
    foreach ($p in $previous.PSObject.Properties) {
        $section, $key = $p.Name -split '\|', 2
        Set-IniValue $lines $section $key $p.Value
    }
    # drop a section this tool added if nothing is left in it
    foreach ($section in $EngineFixes.Keys) {
        $s = Find-Section $lines $section
        if (-not $s) { continue }
        $body = @(); for ($i = $s.head + 1; $i -lt $s.end; $i++) { if ($lines[$i].Trim() -ne '') { $body += $lines[$i] } }
        if ($body.Count -eq 0) { $lines.RemoveRange($s.head, $s.end - $s.head) }
    }
    Write-Ini $EnginePath $lines
    Remove-Item $PrevFile
    Write-Host "The Overhaul's start-up fixes are off. The old values are back."
    exit 0
}
