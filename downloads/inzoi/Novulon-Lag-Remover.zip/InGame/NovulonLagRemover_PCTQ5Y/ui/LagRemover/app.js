/**
 * app.js -- Novulon's Lag Remover.
 * Applies stutter fixes when the game loads, shows a short note, and offers a Details window with a switch per fix.
 * Engine values ("cvar") last for this session only and are applied again every load; game options ("setting")
 * are saved by the game, so the player's own values are remembered and put back when a fix is turned off.
 * Nothing here is tied to one PC: the frame cap follows the screen's refresh rate the player picks, and the
 * texture pool is only ever raised, never lowered.
 */
(function () {
    'use strict';

    var run = lr.run;
    var MOD_ID = 'NovulonLagRemover_PCTQ5Y';
    var SECTION = 'ui/LagRemover/saved';
    var NOTE_SECONDS = 8;
    var KEEP_SECONDS = 45;
    var POOL_MB = 2000;
    var HZ_CHOICES = [60, 75, 120, 144, 165, 240];

    // Highest frame cap the refresh rate divides evenly (165 Hz -> 55, 144 -> 72, 120 -> 60, 240 -> 60).
    function capFor(hz) {
        for (var n = 1; n <= 8; n++) {
            var c = hz / n;
            if (c <= 75 && c >= 30) { return Math.round(c); }
        }
        return null;
    }

    // entries: [kind, key, target, the game's default]
    // target is a value, or a function of the player's own value (the one before this mod touched it).
    // A function target is never forced back to a guessed default when turned off: only a remembered value is restored.
    var FIXES = [
        { id: 'pacing', name: 'Even frame pacing',
          info: "Caps FPS at a number your screen's refresh rate divides evenly, so every frame stays up the same time.",
          entries: [['setting', 'MaxFPS', function () { return saved.hz ? String(capFor(saved.hz)) : null; }, '45']] },
        { id: 'textures', name: 'Bigger texture pool',
          info: 'At least 2,000 MB for textures, so they stop reloading while you walk and drive. Never goes past what the graphics card has.',
          entries: [['cvar', 'r.Streaming.PoolSize', function (base) { return String(Math.max(parseFloat(base) || 0, POOL_MB)); }, '1200']] },
        { id: 'shaders', name: 'Shaders ready early',
          info: 'Prepares shaders while loading instead of the first time something shows up on screen.',
          entries: [['cvar', 'r.CreateShadersOnLoad', '1', '0'], ['cvar', 'r.PSOPrecache.Resources', '1', '0']] },
        { id: 'sky', name: 'Lighter sky updates',
          info: "The game's own option. Redraws the sky less often and looks the same.",
          entries: [['setting', 'SkyUpdateOptimization', '1', '0']] }
    ];

    // on: fix id -> bool; originals: key -> the player's value before the fix; hz: the screen refresh rate picked
    var saved = { on: {}, originals: {}, hz: null };
    var status = {};                         // fix id -> 'on' | 'off' | 'bad' | 'need'

    // ---- storage and log (files under the mod's saved/ folder) ---------------------
    function cfgSave(key, value) {
        return run('uimod.cfg_save', { mod_id: MOD_ID, section: SECTION, key: key, value: value }).catch(function () {});
    }
    function cfgLoad(key) {
        return run('uimod.cfg_load', { mod_id: MOD_ID, section: SECTION, key: key }).then(function (d) {
            var raw = d && typeof d === 'object' ? (d.value != null ? d.value : null) : d;
            if (typeof raw !== 'string' || !raw) { return null; }
            try { return JSON.parse(raw); } catch (e) { return null; }
        }).catch(function () { return null; });
    }
    var logLines = [];
    function log(msg) {
        var t = new Date();
        function p(n) { return (n < 10 ? '0' : '') + n; }
        logLines.push(t.getFullYear() + '-' + p(t.getMonth() + 1) + '-' + p(t.getDate()) + ' ' +
                      p(t.getHours()) + ':' + p(t.getMinutes()) + ':' + p(t.getSeconds()) + ' ' + msg);
        if (logLines.length > 40) { logLines.shift(); }
        cfgSave('log', logLines.join('\n'));
    }
    function store() { return cfgSave('settings', JSON.stringify(saved)); }

    // ---- reading and writing values -------------------------------------------
    function read(kind, key) {
        var p = kind === 'cvar' ? run('graphics.set_cvar', { Name: key }) : run('settings.get', { Option: key });
        return p.then(function (d) { return d && d.value != null ? String(d.value) : null; });
    }
    function write(kind, key, value) {
        return kind === 'cvar' ? run('graphics.set_cvar', { Name: key, Value: String(value) })
                               : run('settings.set', { Option: key, Value: String(value) });
    }
    function same(a, b) {
        var x = parseFloat(a), y = parseFloat(b);
        if (!isNaN(x) && !isNaN(y)) { return Math.abs(x - y) < 0.01; }
        return String(a) === String(b);
    }
    function inOrder(list, fn) {
        return list.reduce(function (p, item) { return p.then(function () { return fn(item); }); }, Promise.resolve());
    }
    function targetOf(entry, cur) {
        var key = entry[1], t = entry[2];
        if (typeof t !== 'function') { return t; }
        return t(key in saved.originals ? saved.originals[key] : cur);
    }

    function turnOn(fix) {
        var ok = true, need = false;
        return inOrder(fix.entries, function (e) {
            var kind = e[0], key = e[1];
            return read(kind, key).then(function (cur) {
                var target = targetOf(e, cur);
                if (target == null) { need = true; return; }
                if (!(key in saved.originals) && cur != null && !same(cur, target)) { saved.originals[key] = cur; }
                return (same(cur, target) ? Promise.resolve() : write(kind, key, target)).then(function () {
                    return read(kind, key);
                }).then(function (now) {
                    if (!same(now, target)) { ok = false; log(key + ' stayed at ' + now); }
                });
            }).catch(function (err) { ok = false; log(key + ': ' + ((err && err.message) || err)); });
        }).then(function () { status[fix.id] = need ? 'need' : ok ? 'on' : 'bad'; });
    }

    function turnOff(fix) {
        var ok = true;
        return inOrder(fix.entries, function (e) {
            var kind = e[0], key = e[1];
            var back = key in saved.originals ? saved.originals[key] : typeof e[2] === 'function' ? null : e[3];
            if (back == null) { return; }   // never changed by this mod, nothing to put back
            return write(kind, key, back).then(function () { return read(kind, key); }).then(function (now) {
                if (!same(now, back)) { ok = false; log(key + ' did not go back, still ' + now); }
                else { delete saved.originals[key]; }
            }).catch(function (err) { ok = false; log(key + ': ' + ((err && err.message) || err)); });
        }).then(function () { status[fix.id] = ok ? 'off' : 'bad'; });
    }

    // The game can reset engine values (for example when it lowers settings on its own); put them back.
    function keep() {
        FIXES.forEach(function (fix) {
            if (!saved.on[fix.id] || status[fix.id] !== 'on') { return; }
            fix.entries.forEach(function (e) {
                if (e[0] !== 'cvar') { return; }
                read(e[0], e[1]).then(function (cur) {
                    var target = targetOf(e, cur);
                    if (cur != null && target != null && !same(cur, target)) {
                        log('Put back ' + e[1] + ' (the game changed it to ' + cur + ')');
                        return write(e[0], e[1], target);
                    }
                }).catch(function () {});
            });
        });
    }

    // ---- screen ------------------------------------------------------------------------
    var note = document.getElementById('note');
    var panel = document.getElementById('panel');
    var noteSub = document.getElementById('note-sub');
    var fixesBox = document.getElementById('fixes');
    var allOff = document.getElementById('all-off');
    lr.view.bind(note);
    lr.view.bind(panel);

    // Empty game view above the needs panel at the bottom left (the needs panel starts at x 285, y 1010 of 1200).
    // The bottom right is busy: money, the HUD icon row and the game's own side windows.
    var screenH = 1200;
    function place() {
        var s = window.innerHeight / screenH;
        var left = Math.round(285 * s), bottom = Math.round(205 * s);
        note.style.left = left + 'px'; note.style.bottom = bottom + 'px';
        panel.style.left = left + 'px'; panel.style.bottom = bottom + 'px';
        panel.style.maxHeight = Math.max(300, window.innerHeight - bottom - Math.round(110 * s)) + 'px';
    }
    window.addEventListener('resize', function () { place(); lr.view.report(); });

    var noteTimer = null, noteHovered = false;
    note.addEventListener('mouseenter', function () { noteHovered = true; });
    note.addEventListener('mouseleave', function () { noteHovered = false; });

    function noteText() {
        var count = FIXES.filter(function (f) { return status[f.id] === 'on'; }).length;
        var bad = FIXES.filter(function (f) { return status[f.id] === 'bad'; }).length;
        if (saved.on.pacing && status.pacing === 'need') {
            return count + (count === 1 ? ' fix' : ' fixes') + ' on. Pick your screen in Details for even frames.';
        }
        if (count === 0) { return 'All fixes are off.'; }
        return count + (count === 1 ? ' fix' : ' fixes') + ' on' +
               (status.pacing === 'on' && saved.hz ? ', ' + capFor(saved.hz) + ' FPS cap' : '') +
               (bad ? '. ' + bad + ' could not be changed' : '') + '.';
    }

    function showNote() {
        noteSub.textContent = noteText();
        panel.classList.remove('show');
        note.classList.add('show');
        lr.view.track(note);
        log('note: ' + noteSub.textContent);
        clearTimeout(noteTimer);
        (function wait(left) {
            noteTimer = setTimeout(function () {
                if (noteHovered) { wait(2); return; }
                hideNote();
            }, left * 1000);
        })(NOTE_SECONDS);
    }
    function hideNote() {
        clearTimeout(noteTimer);
        note.classList.remove('show');
        if (!panel.classList.contains('show')) { lr.view.track(null); }
    }

    function stateText(fix) {
        var s = status[fix.id];
        if (s === 'bad') { return { text: 'The game did not take this one.', cls: 'bad' }; }
        if (s === 'need') { return { text: 'Pick your screen below to turn this on.', cls: '' }; }
        if (s === 'on' && fix.id === 'pacing' && saved.hz) { return { text: 'On, ' + capFor(saved.hz) + ' FPS', cls: 'ok' }; }
        return s === 'on' ? { text: 'On', cls: 'ok' } : { text: 'Off', cls: '' };
    }

    function el(tag, cls, text) {
        var e = document.createElement(tag);
        if (cls) { e.className = cls; }
        if (text != null) { e.textContent = text; }
        return e;
    }

    // Screen refresh rate picker inside the frame pacing card.
    function hzPicker(fix) {
        var box = el('div', 'hz');
        box.appendChild(el('div', 'hz-label muted', 'Screen Hz'));
        HZ_CHOICES.forEach(function (hz) {
            var chip = el('div', 'chip' + (saved.hz === hz ? ' on' : ''), String(hz));
            chip.addEventListener('click', function () {
                saved.hz = hz;
                saved.on.pacing = true;
                turnOn(fix).then(store).then(drawPanel);
            });
            box.appendChild(chip);
        });
        return box;
    }

    function drawPanel() {
        fixesBox.innerHTML = '';
        FIXES.forEach(function (fix) {
            var on = saved.on[fix.id] && status[fix.id] !== 'need';
            var row = el('div', 'fix' + (on ? ' on' : ''));
            var text = el('div', 'fix-text');
            text.appendChild(el('div', 'fix-name', fix.name));
            text.appendChild(el('div', 'fix-info muted', fix.info));
            if (fix.id === 'pacing') { text.appendChild(hzPicker(fix)); }
            var st = stateText(fix);
            text.appendChild(el('div', 'fix-state ' + st.cls, st.text));
            var sw = el('div', 'switch' + (on ? ' on' : ''));
            sw.appendChild(el('div', 'knob'));
            sw.addEventListener('click', function () {
                saved.on[fix.id] = !on;
                (saved.on[fix.id] ? turnOn(fix) : turnOff(fix)).then(store).then(drawPanel);
            });
            row.appendChild(text); row.appendChild(sw);
            fixesBox.appendChild(row);
        });
        var anyOn = FIXES.some(function (f) { return saved.on[f.id] && status[f.id] === 'on'; });
        allOff.textContent = anyOn ? 'Turn all off' : 'Turn all on';
    }

    // Novulon windows never stack: each one writes shared/open when it opens, and an open one closes itself
    // when another Novulon mod's shared/open changes after it opened.
    var OTHER_MODS = ['NovulonStatCheats_WWPRTR', 'NovulonAIRemade_6U5ANM'];
    var watchTimer = null, baseline = {};
    function sharedOpen(id) {
        return run('uimod.cfg_load', { mod_id: id, section: 'shared', key: 'open' }).then(function (d) {
            var v = d && typeof d === 'object' ? d.value : d;
            return v == null ? '' : String(v);
        }).catch(function () { return ''; });   // not installed, or never opened
    }
    function announceOpen() {
        run('uimod.cfg_save', { mod_id: MOD_ID, section: 'shared', key: 'open', value: String(Date.now()) }).catch(function () {});
    }
    function watchOthers() {
        clearInterval(watchTimer);
        baseline = {};
        Promise.all(OTHER_MODS.map(sharedOpen)).then(function (vals) {
            OTHER_MODS.forEach(function (id, i) { baseline[id] = vals[i]; });
            watchTimer = setInterval(function () {
                OTHER_MODS.forEach(function (id) {
                    sharedOpen(id).then(function (v) {
                        if (v && v !== baseline[id] && panel.classList.contains('show')) { closePanel(); }
                    });
                });
            }, 600);
        });
    }

    function openPanel() {
        hideNote();
        drawPanel();
        panel.classList.add('show');
        lr.view.track(panel);
        announceOpen();
        watchOthers();
    }
    function closePanel() {
        clearInterval(watchTimer);
        panel.classList.remove('show');
        lr.view.track(null);
    }

    document.getElementById('note-hide').addEventListener('click', hideNote);
    document.getElementById('note-open').addEventListener('click', openPanel);
    document.getElementById('panel-x').addEventListener('click', closePanel);
    document.getElementById('done').addEventListener('click', closePanel);
    allOff.addEventListener('click', function () {
        var anyOn = FIXES.some(function (f) { return saved.on[f.id] && status[f.id] === 'on'; });
        inOrder(FIXES, function (fix) {
            saved.on[fix.id] = !anyOn;
            return anyOn ? turnOff(fix) : turnOn(fix);
        }).then(store).then(drawPanel);
    });

    // ---- start ---------------------------------------------------------------------
    // Settings saved before the refresh-rate picker existed had a fixed 55 FPS cap: that was a 165 Hz screen.
    function migrate(s) {
        if (!saved.hz && s && s.on && s.on.pacing && s.originals && 'MaxFPS' in s.originals) { saved.hz = 165; }
    }

    function start() {
        run('ui.list_windows', {}).then(function (d) {
            if (d && d.screen && d.screen[1]) { screenH = d.screen[1]; }
        }).catch(function () {}).then(function () {
            place();
            log('view ' + window.innerWidth + 'x' + window.innerHeight + ', screen height ' + screenH);
            return cfgLoad('settings');
        }).then(function (s) {
            if (s && typeof s === 'object') {
                saved.on = s.on || {};
                saved.originals = s.originals || {};
                saved.hz = s.hz || null;
                migrate(s);
            }
            FIXES.forEach(function (f) { if (!(f.id in saved.on)) { saved.on[f.id] = true; } });
            return inOrder(FIXES, function (fix) {
                if (saved.on[fix.id]) { return turnOn(fix); }
                status[fix.id] = 'off';
            });
        }).then(store).then(function () {
            setInterval(keep, KEEP_SECONDS * 1000);
            // "open" = "details" (written with uimod.cfg_save) opens the window once, used for store screenshots
            return cfgLoad('open');
        }).then(function (open) {
            if (open === 'details') { cfgSave('open', ''); openPanel(); } else { showNote(); }
        }).catch(function (err) { log('start: ' + ((err && err.message) || err)); });
    }

    lr.view.track(null);
    setTimeout(start, 1500);
})();
