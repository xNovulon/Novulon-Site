-- Novulon's AI Remade: commands from the window arrive on the controlled zoi's script.
local S = require('NvShared')
local M = {}

function M.on_lua_message(self, owner, msgType, content)
    if msgType == 'nv_cmd' and S.handle then
        local ok, err = pcall(S.handle, tostring(content))
        if not ok then S.send('nv_err', { where = 'cmd', err = err }) end
    end
end

return M