-- Novulon's AI Remade: the game's dice rolls between the player and another adult.
-- The attraction level tilts the roll; "always accept" makes it pass. Kids and teens are never touched.
local S = require('NvShared')
local M = {}

local GROWN = { [32] = true, [64] = true, [128] = true, [256] = true }
local logged = 0

local function grown(id)
    local bio = S.bio[id]
    if not bio then return false end
    local ok, g = pcall(function() return bio:GetGrowthStep() end)
    return ok and GROWN[tonumber(g) or -1] == true
end

local function decide(name, args)
    local ctx, cond
    if type(args[1]) == 'table' then ctx, cond = args[2], args[3] else ctx, cond = args[1], args[2] end
    local okb, base = pcall(function() return inzoi.FB2Script_System[name](ctx, cond) end)
    if not okb then return false end
    local cfg, p = S.cfg, S.pid
    if not p or not (cfg.attract or cfg.accept or cfg.logDice) then return base end
    local ok, sid, tid = pcall(function() return tostring(ctx.SelfEntityId), tostring(ctx.TargetEntityId) end)
    if not ok or (sid ~= p and tid ~= p) then return base end
    local other = (sid == p) and tid or sid
    if other == p or not grown(other) or not grown(p) then return base end
    local result = base
    if cfg.accept then
        result = true
    elseif cfg.attract and cfg.level ~= 0 then
        local r = math.random()
        if cfg.level > 0 and not base and r < cfg.level / 10 then result = true end
        if cfg.level < 0 and base and r < -cfg.level / 10 then result = false end
    end
    if cfg.logDice and logged < 400 then
        logged = logged + 1
        pcall(function()
            S.send('nv_dice', { fn = name, self = sid, target = tid, why = tostring(ctx.PlayReason),
                cmd = tostring(cond.Command), f1 = tostring(cond.F1), f2 = tostring(cond.F2),
                s1 = tostring(cond.S1), s2 = tostring(cond.S2), base = base, result = result })
        end)
    end
    return result
end

function M.Override_Condition_CheckDice(...) return decide('Condition_CheckDice', { ... }) end
function M.Override_Condition_CheckDiceWithRoll(...) return decide('Condition_CheckDiceWithRoll', { ... }) end

return M