-- Novulon's AI Remade: simulation-side logic.
--   * catches actions the controlled zoi starts on its own (autonomy, needs, schedule) and asks first
--   * ends a conversation when the controlled zoi walks away from the other person
--   * changes other adults' romance preferences toward the player, and can undo it
local S = require('NvShared')
local M = {}

-- the shared table survives a remount, so fields added in newer versions are filled in here
S.allowBag = S.allowBag or {}
S.allowWhy = S.allowWhy or {}
S.lastAsk = S.lastAsk or {}
S.into = S.into or {}          -- adult id -> how into the player they are, 0-100 (kept by the window)

local GROWN = { [32] = true, [64] = true, [128] = true, [256] = true }       -- Youth, Adult, Old, Elderly
-- play reasons for actions the player didn't pick (EB1InteractionPlayReason)
-- (emergencies, 54 and 55, are left alone so the zoi can't starve or collapse)
local SELF_STARTED = { [8] = 'autonomy', [9] = 'need', [10] = 'schedule', [11] = 'coop', [15] = 'life', [16] = 'howling',
                       [30] = 'site', [32] = 'home', [39] = 'smartzoi', [51] = 'work', [58] = 'smartzoi' }
local seenQ = {}
local CANCEL_USER = 43

local clock, lastGuard, lastWalk = 0, 0, 0
local handled = {}      -- queue ids already caught

local function parse(s)
    local t = {}
    for k, v in string.gmatch(s, '([%w_]+)=([^;]*)') do t[k] = v end
    return t
end

local function possessed()
    local ok, v = pcall(function() return inzoi.FB2ControllerSystem.GetPossessEntityId() end)
    if ok and v ~= nil then return tostring(v) end
    return nil
end

local function grown(id)
    local bio = S.bio[id]
    if not bio then return false end
    local ok, g = pcall(function() return bio:GetGrowthStep() end)
    return ok and GROWN[tonumber(g) or -1] == true
end

local function dist(a, b)
    local ok, d = pcall(function()
        local la, lb = S.ic[a]:GetOwnerLocation(), S.ic[b]:GetOwnerLocation()
        local dx, dy = la.X - lb.X, la.Y - lb.Y
        return math.sqrt(dx * dx + dy * dy)
    end)
    return ok and d or nil
end

-- ---- asking before acting alone --------------------------------------------
local function guard(p)
    local ic = S.ic[p]
    if not ic then return end
    local ok, reason = pcall(function() return ic:GetCurrentInteractionPlayReason() end)
    if not ok then return end
    if S.cfg.logDice then   -- learning: every new action of the controlled zoi with its reason
        local okq, q = pcall(function() return tostring(ic:GetCurrentInteractionQueueId()) end)
        if okq and q and not seenQ[q] then
            seenQ[q] = true
            local bag = ''
            pcall(function() bag = tostring(ic:GetInteractionId(ic:GetCurrentInteractionQueueId())) end)
            S.send('nv_seen', { bag = bag, reason = tostring(reason) })
        end
    end
    local why = SELF_STARTED[tonumber(reason) or -1]
    if not why then return end
    local qid = ic:GetCurrentInteractionQueueId()
    local key = tostring(qid)
    if handled[key] then return end
    local bag = tostring(ic:GetInteractionId(qid))
    handled[key] = true
    -- the player said yes to this kind of action a moment ago: let the game's own retry through
    if (S.allowBag[bag] or 0) > clock or (S.allowWhy[why] or 0) > clock then return end
    -- small things played on the spot (idles, reactions, self actions) are left alone
    if bag:sub(1, 5) == 'Self_' or bag:sub(1, 4) == 'Idle' or bag:sub(1, 8) == 'Reaction' then return end
    local target = ''
    pcall(function() target = tostring(ic:GetInteractionTargetEntityId(qid)) end)
    if target == p then return end
    -- someone came over to talk or flirt: that happens where they stand, so it stays
    if why == 'coop' and S.ic[target] then return end
    -- stop the feet first, then drop the action, so the zoi doesn't take extra steps
    pcall(function()
        local ch = inzoi.FB2EntityManager.Get():FindCharacter(inzoi.FB2ControllerSystem.GetPossessEntityId())
        ch:SendCancelWalkTo()
    end)
    local cancelled = pcall(function() ic:TryCancelInteraction(qid, CANCEL_USER, nil) end)
    if not cancelled then cancelled = pcall(function() ic:TryCancelInteraction(qid, CANCEL_USER) end) end
    if (S.lastAsk[bag] or -99) > clock - 8 then return end    -- the game retries fast; ask once per few seconds
    S.lastAsk[bag] = clock
    S.send('nv_ask', { who = p, bag = bag, target = target, why = why, cancelled = cancelled })
end

-- ---- walking away ends a conversation --------------------------------------------
local function walkaway(p)
    local tc, ic = S.talk[p], S.ic[p]
    if not tc or not ic then return end
    local okT, talking = pcall(function() return tc:IsTalking() end)
    if not okT or not talking then return end
    local other
    pcall(function() other = tostring(ic:GetInteractionTargetEntityId(ic:GetCurrentInteractionQueueId())) end)
    local d = (other and S.ic[other]) and dist(p, other) or nil
    if S.cfg.logDice and clock - (S.lastWalkLog or 0) > 3 then
        S.lastWalkLog = clock
        S.send('nv_walk', { other = tostring(other), meters = d and math.floor(d / 10) / 10 or -1 })
    end
    if not other or other == p or not S.ic[other] then return end
    if d and d > S.cfg.walkDist * 100 then
        pcall(function() tc:LeaveTalk() end)
        S.send('nv_info', { what = 'walked_away', other = other, meters = math.floor(d / 100) })
    end
end

-- ---- smarter zois: who is idle near whom around the player ------------------------------------------
-- Sends pairs of idle zois close to each other (within 3 m, same floor) near the player. The window
-- starts a friendly greeting between them; for zois standing inside each other that also spaces them out,
-- since the game's talk positioning steps them apart.
local function crowd(p)
    local pl = S.ic[p]
    if not pl then return end
    local okp, ploc = pcall(function() return pl:GetOwnerLocation() end)
    if not okp or not ploc then return end
    local near = {}
    for id, ic in pairs(S.ic) do
        if id ~= p then
            local okl, loc = pcall(function() return ic:GetOwnerLocation() end)
            if okl and loc then
                local dx, dy = loc.X - ploc.X, loc.Y - ploc.Y
                if dx * dx + dy * dy < 2500 * 2500 then
                    local okb, busy = pcall(function() return ic:IsPlayingInteraction() end)
                    if okb and not busy then near[#near + 1] = { id = id, x = loc.X, y = loc.Y, z = loc.Z } end
                end
            end
        end
    end
    local out = {}
    for i = 1, #near do
        for j = i + 1, #near do
            local a, b = near[i], near[j]
            if math.abs(a.z - b.z) < 150 then
                local dx, dy = a.x - b.x, a.y - b.y
                local d = math.sqrt(dx * dx + dy * dy)
                if d < 300 then out[#out + 1] = a.id .. ':' .. b.id .. ':' .. math.floor(d) end
            end
            if #out >= 8 then break end
        end
        if #out >= 8 then break end
    end
    if #out > 0 then S.send('nv_pairs', { v = table.concat(out, ';') }) end
end

-- ---- preferences ------------------------------------------------------------------
local GENDERS = { 1, 2, 3 }   -- Male, Female, NonBinary

local function snapshot(g)
    local flags = {}
    for _, gi in ipairs(GENDERS) do
        local ok, has = pcall(function() return g.RomanceTargetList:Contains(gi) end)
        flags[#flags + 1] = (ok and has) and '1' or '0'
    end
    return (g.bRomanticOrientation and '1' or '0') .. ':' .. table.concat(flags, ':')
end

local function match(ids, gender)
    local changed, skipped, orig = 0, 0, {}
    for id in string.gmatch(ids or '', '[^,]+') do
        local bio = S.bio[id]
        if bio and grown(id) and id ~= S.pid then
            local ok = pcall(function()
                local g = bio:GetGenderIdentitySetting()
                orig[#orig + 1] = id .. ':' .. snapshot(g)
                g.bRomanticOrientation = true
                g.RomanceTargetList:Add(gender)
                bio:SetGenderIdentitySetting(g, false)
            end)
            if ok then changed = changed + 1 else skipped = skipped + 1 end
        else
            skipped = skipped + 1
        end
    end
    S.send('nv_prefs', { mode = 'match', changed = changed, skipped = skipped, orig = table.concat(orig, '|') })
end

local function restore(list)
    local done = 0
    for entry in string.gmatch(list or '', '[^|]+') do
        local id, o, m, f, n = entry:match('^(%d+):(%d):(%d):(%d):(%d)$')
        local bio = id and S.bio[id]
        if bio then
            local ok = pcall(function()
                local g = bio:GetGenderIdentitySetting()
                g.bRomanticOrientation = (o == '1')
                local want = { [1] = m == '1', [2] = f == '1', [3] = n == '1' }
                for gi, on in pairs(want) do
                    if on then g.RomanceTargetList:Add(gi) else pcall(function() g.RomanceTargetList:Remove(gi) end) end
                end
                bio:SetGenderIdentitySetting(g, false)
            end)
            if ok then done = done + 1 end
        end
    end
    S.send('nv_prefs', { mode = 'restore', changed = done })
end

-- ---- commands from the window ------------------------------------------------------
S.handle = function(content)
    local c = parse(content)
    if c.op == 'settings' then
        S.cfg.needs = c.needs == '1'
        S.cfg.walkaway = c.walk == '1'
        S.cfg.walkDist = tonumber(c.dist) or 6
        S.cfg.attract = c.attract == '1'
        S.cfg.level = math.max(-10, math.min(10, tonumber(c.level) or 0))
        S.cfg.accept = c.accept == '1'
        S.cfg.logDice = c.logdice == '1'
        S.send('nv_state', { what = 'settings', seq = c.seq or '' })
    elseif c.op == 'prefs' and c.mode == 'match' then
        match(c.ids, tonumber(c.gender) or 1)
    elseif c.op == 'prefs' and c.mode == 'restore' then
        restore(c.orig)
    elseif c.op == 'into' then
        for id, v in string.gmatch(c.v or '', '(%d+):(%d+)') do S.into[id] = tonumber(v) end
    elseif c.op == 'allow' then
        local secs = tonumber(c.secs) or 180
        if c.bag and c.bag ~= '' then S.allowBag[c.bag] = clock + secs end
        if c.why and c.why ~= '' then S.allowWhy[c.why] = clock + secs end
    elseif c.op == 'ping' then
        S.send('nv_state', { what = 'pong', seq = c.seq or '' })
    end
end

function M.on_begin()
    S.send('nv_hello', { lua = true })
end

function M.on_tick(a, b)
    local dt = tonumber(b) or tonumber(a) or 0.016
    clock = clock + dt
    local p = possessed()
    S.pid = p
    if not p then return end
    if S.cfg.needs and clock - lastGuard > 0.05 then
        lastGuard = clock
        local ok, err = pcall(guard, p)
        if not ok then S.send('nv_err', { where = 'guard', err = err }) end
    end
    if clock - (S.lastCrowd or 0) > 4 then     -- smarter zois: always on
        S.lastCrowd = clock
        local okc, errc = pcall(crowd, p)
        if not okc then S.send('nv_err', { where = 'crowd', err = errc }) end
    end
    if S.cfg.walkaway and clock - lastWalk > 0.5 then
        lastWalk = clock
        pcall(walkaway, p)
    end
end

function M.on_end()
end

return M