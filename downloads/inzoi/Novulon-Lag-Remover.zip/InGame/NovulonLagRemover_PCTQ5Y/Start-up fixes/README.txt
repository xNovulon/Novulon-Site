Novulon's Lag Remover for inZOI
===============================

Fewer FPS spikes and smoother frames. Graphics stay exactly as they are.

What it changes
---------------
- Even frame pacing: caps FPS at a number your screen's refresh rate divides evenly (165 Hz: 55,
  144 Hz: 72, 120 Hz: 60, 60 Hz: 60). With V-Sync every frame then stays on screen for the same time.
  A cap like 45 on a 165 Hz screen jitters. Pick your screen in the Details window once.
- Bigger texture pool: at least 2,000 MB, so textures stop reloading while walking and driving.
  It never lowers a bigger pool and never goes past what the graphics card has.
- Shaders ready early: shaders and pipelines are prepared while loading instead of the first time
  something appears, which is what causes most one-off hitches.
- Lighter sky updates: the game's own option. The sky is redrawn less often and looks the same.

Two parts
---------
1. The in-game mod (folder NovulonLagRemover_PCTQ5Y)
   Put it in Documents\inZOI\Mods. It works on its own.
   A short note shows above the needs panel when you load in. Details has a switch for every fix,
   and turning one off puts your old value back.

2. The start-up fixes (this folder, optional)
   Makes the shader fixes count from the very first loading screen too.
   Close inZOI, then double-click "Apply Lag Remover.cmd" once.
   "Undo Lag Remover.cmd" puts Engine.ini back exactly as it was.
   Both refuse to run while the game is open, because the game rewrites the file when it closes.

Also helps (one time)
---------------------
- Laptops: keep the charger plugged in while playing. On battery the GPU runs much slower.
- Windows power mode: Settings > System > Power & battery > Power mode > Best performance.
- A hot laptop slows itself down, and that shows up as spikes. Give it air or use a cooling pad.
- NVIDIA Control Panel > Manage 3D settings > Shader Cache Size > 10 GB, so compiled shaders are
  never thrown away and rebuilt mid-game.
- If busy streets still spike, lowering Population density one step helps the CPU the most.
