-- Novulon's AI Remade: replies to the player's phone invites (make plans, come over, messages).
-- "Always accept" turns a no into a yes; otherwise the attraction level tilts the reply. Adults only.
local S = require('NvShared')
local M = {}

local GROWN = { [32] = true, [64] = true, [128] = true, [256] = true }
local POSITIVE, NEGATIVE = 1, 2

local function grown(id)
    local bio = S.bio[id]
    if not bio then return false end
    local ok, g = pcall(function() return bio:GetGrowthStep() end)
    return ok and GROWN[tonumber(g) or -1] == true
end

-- per-entity overrides may arrive as (self, comp, ...) or (comp, ...)
local function unpackArgs(...)
    local a = { ... }
    if type(a[1]) == 'table' then table.remove(a, 1) end
    return a
end

local function decide(sender, receiver, t)
    local p = S.pid
    local n = tonumber(t)
    if not p or not n then return t end
    local s, r = tostring(sender), tostring(receiver)
    if s ~= p and r ~= p then return t end
    local other = (s == p) and r or s
    if other == p or not grown(other) or not grown(p) then return t end
    local cfg = S.cfg
    if n == NEGATIVE and cfg.accept then return POSITIVE end
    if cfg.attract and cfg.level ~= 0 then
        local roll = math.random()
        if n == NEGATIVE and cfg.level > 0 and roll < cfg.level / 10 then return POSITIVE end
        if n == POSITIVE and cfg.level < 0 and roll < -cfg.level / 10 then return NEGATIVE end
    end
    return t
end

local function hook(name)
    return function(...)
        local a = unpackArgs(...)
        local comp, sender, receiver, sys, t = a[1], a[2], a[3], a[4], a[5]
        local nt = t
        local ok = pcall(function() nt = decide(sender, receiver, t) end)
        if not ok then nt = t end
        if S.cfg.logDice then
            S.send('nv_phone', { fn = name, sender = tostring(sender), receiver = tostring(receiver), was = tostring(t), now = tostring(nt) })
        end
        return comp[name](comp, sender, receiver, sys, nt)
    end
end

M.Override_SendMessageResponse = hook('SendMessageResponse')
M.Override_SendMessageResponseInternal = hook('SendMessageResponseInternal')

return M