/**
 * shell.js -- input for a full-screen overlay view with several small hot areas
 * (the HUD button, the window, the top popup). Replaces the scaffold's window.js.
 *
 * The game sends clicks to this view only inside the rect reported with setContentRect, so the
 * rect follows whichever hot area the mouse is over. Native click events are unreliable in cohtml,
 * so a click is synthesized on mouseup.
 */
(function () {
    'use strict';

    var MOD_ID = window.__uimod_mod_id || 'NovulonAIRemade_6U5ANM';
    var APP_NAME = 'Hub';

    function cli(cmd, params) { return inzoi.cli.execute(cmd, params || {}); }

    function hover(on) {
        try { if (window.inzoi && inzoi.view && inzoi.view.hover) { inzoi.view.hover(!!on); return; } } catch (e) {}
        try { engine.call('_uimod_request', JSON.stringify({ type: 'view', action: 'hover', over: !!on, promiseId: 0 })); } catch (e2) {}
    }
    function reportRect(r) {
        try { if (window.inzoi && inzoi.view && inzoi.view.setContentRect) { inzoi.view.setContentRect(r.x, r.y, r.w, r.h); } } catch (e) {}
    }

    var areas = [], current = null, home = null;

    function shown(elm) {
        if (!elm || !elm.parentNode) { return false; }
        for (var n = elm; n && n !== document.body; n = n.parentNode) {
            if (n.style && n.style.display === 'none') { return false; }
        }
        return true;
    }
    function rectOf(elm) {
        var b = elm.getBoundingClientRect();
        return { x: Math.floor(b.left), y: Math.floor(b.top), w: Math.ceil(b.width), h: Math.ceil(b.height) };
    }
    function areaAt(x, y) {
        for (var i = areas.length - 1; i >= 0; i--) {
            var a = areas[i];
            if (!shown(a)) { continue; }
            var b = a.getBoundingClientRect();
            if (x >= b.left && x < b.right && y >= b.top && y < b.bottom) { return a; }
        }
        return null;
    }
    function settle() {
        if (current && shown(current)) { reportRect(rectOf(current)); return; }
        current = null;
        hover(false);
        if (home && shown(home)) { reportRect(rectOf(home)); } else { reportRect({ x: 0, y: 0, w: 1, h: 1 }); }
    }
    document.addEventListener('mousemove', function (e) {
        var a = areaAt(e.clientX, e.clientY);
        if (a !== current) {
            current = a;
            if (a) { reportRect(rectOf(a)); hover(true); } else { hover(false); }
        }
    });
    function addArea(elm, isHome) {
        areas.push(elm);
        if (isHome) { home = elm; }
        elm.addEventListener('wheel', function (e) { e.stopPropagation(); }, { passive: false });
        settle();
    }

    // reliable clicks
    var downTarget = null, guard = false;
    document.addEventListener('mousedown', function (e) { if (e.button === 0) { downTarget = e.target; } }, true);
    document.addEventListener('mouseup', function (e) {
        if (e.button !== 0) { return; }
        var dt = downTarget; downTarget = null;
        if (!dt) { return; }
        var up = e.target;
        var same = up === dt || (dt.contains && dt.contains(up)) || (up.contains && up.contains(dt));
        if (!same) { return; }
        guard = true;
        var evt;
        try { evt = new MouseEvent('click', { bubbles: true, cancelable: true }); }
        catch (err) { evt = document.createEvent('MouseEvents'); evt.initEvent('click', true, true); }
        evt._nvSynthetic = true;
        up.dispatchEvent(evt);
        setTimeout(function () { guard = false; }, 0);
    }, true);
    document.addEventListener('click', function (e) {
        if (e._nvSynthetic) { return; }
        if (guard) { e.stopImmediatePropagation(); e.preventDefault(); }
    }, true);

    window.wf = { cli: cli, MOD_ID: MOD_ID, APP_NAME: APP_NAME };
    window.shell = { addArea: addArea, settle: settle, hover: hover };
})();
