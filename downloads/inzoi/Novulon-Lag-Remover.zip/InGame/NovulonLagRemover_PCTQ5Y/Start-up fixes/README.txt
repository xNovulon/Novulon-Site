Novulon's Lag Remover for inZOI
===============================

Less lag and fewer sudden freezes, without lowering your graphics.

What you'll notice
------------------
- Steady frame rate: no more jitter. Pick your screen's Hz once in the Details window.
- Less loading while you move: things stop going blurry and popping in while you walk and drive.
- Fewer sudden freezes: the game stops freezing the first time something new shows up.
- Lighter sky: uses the game's own setting. The sky looks exactly the same.
- Same graphics: nothing is turned down.
- Easy to undo: every fix has its own switch, and turning one off brings back what you had.

Install
-------
1. Put the NovulonLagRemover_PCTQ5Y folder in Documents\inZOI\Mods.
2. Load a save. A short note shows above your needs. Open Details and pick your screen's Hz.
3. Optional, for fewer freezes during loading too: close inZOI and double-click
   "Apply Lag Remover.cmd" once. "Undo Lag Remover.cmd" takes it back out.
   Both only work while the game is closed.

Also helps
----------
- Laptops: keep the charger plugged in while playing.
- Windows: Settings > System > Power & battery > Power mode > Best performance.
- Keep your PC cool. A hot laptop slows itself down, and that feels like lag.
- NVIDIA: Control Panel > Manage 3D settings > Shader Cache Size > 10 GB.
- Busy streets still lagging? Lower Population density one step in the game's settings.
