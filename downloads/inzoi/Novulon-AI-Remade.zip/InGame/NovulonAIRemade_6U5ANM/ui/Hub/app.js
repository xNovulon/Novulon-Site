/**
 * app.js -- Novulon's AI Remade.
 *   Behavior: ask before the controlled zoi acts alone, walking away ends a talk, over-the-shoulder camera.
 *   Attraction: a -10..+10 level, adults nearby come over and flirt, invites get accepted, preferences.
 * Adults only for anything romantic: kids and teens are never listed, picked or affected.
 */
(function () {
    'use strict';

    var MOD = wf.MOD_ID;
    var SAVED = 'ui/Hub/saved';
    var GROWN = { Youth: 1, YoungAdult: 1, Adult: 1, Old: 1, Elder: 1, Elderly: 1 };
    var KIDS_WORDS = /teen|child|kid|infant|toddler|baby|school|student/i;

    // ---- small helpers ---------------------------------------------------------------
    function parseLoose(text) {
        if (typeof text !== 'string') { return text; }
        text = text.replace(/\\'/g, "'");   // the game writes \' inside names ("You\'ve"), which JSON rejects
        try { return JSON.parse(text); } catch (e) {}
        var i = text.search(/[\[{]/);
        if (i > 0) { try { return JSON.parse(text.slice(i)); } catch (e2) {} }
        return null;
    }
    function run(cmd, params) {
        return Promise.resolve(wf.cli(cmd, params || {})).then(function (res) {
            if (res == null) { throw new Error(cmd + ': no answer'); }
            if (res.success === false) { throw new Error(String(res.message || (cmd + ' failed'))); }
            var d = res.data;
            if (typeof d === 'string') { d = parseLoose(d); }
            if (d == null && typeof res.message === 'string') { d = parseLoose(res.message); }
            return d == null ? res : d;
        });
    }
    function el(tag, cls, text) {
        var e = document.createElement(tag);
        if (cls) { e.className = cls; }
        if (text != null) { e.textContent = text; }
        return e;
    }
    function icon(paths) {
        var s = el('div');
        s.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + paths + '</svg>';
        return s.firstChild;
    }
    var ICON = {
        brain: '<path d="M9 4.5a3 3 0 0 0-3 3v.2A3 3 0 0 0 4.5 13a3 3 0 0 0 2 4.8A3 3 0 0 0 12 19V5.5A3 3 0 0 0 9 4.5z"/><path d="M15 4.5a3 3 0 0 1 3 3v.2a3 3 0 0 1 1.5 5.3 3 3 0 0 1-2 4.8A3 3 0 0 1 12 19"/><path d="M12 9h2.5M12 13.5h3"/>',
        x: '<path d="M6 6l12 12M18 6L6 18"/>',
        check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
        food: '<path d="M7 3v8M5 3v5a2 2 0 0 0 4 0V3M7 11v10"/><path d="M17 3c-2 1.5-3 4-3 7h3v11"/>',
        drop: '<path d="M12 3.5c3 4 5 6.6 5 9.5a5 5 0 0 1-10 0c0-2.9 2-5.5 5-9.5z"/>',
        moon: '<path d="M19 14.5A7.5 7.5 0 0 1 9.5 5a7.5 7.5 0 1 0 9.5 9.5z"/>',
        talk: '<path d="M5 6h14v9H10l-4 3v-3H5z"/>',
        star: '<path d="M12 4l2.3 4.8 5.2.7-3.8 3.6.9 5.2L12 15.9 7.4 18.3l.9-5.2-3.8-3.6 5.2-.7z"/>',
        walk: '<circle cx="13" cy="4.5" r="1.8"/><path d="M11 21l2-6-2.5-2.5L12 8l3 3h3M9 10l-2 4"/>',
        heart: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>'
    };

    var logLines = [];
    function log(msg) {
        var d = new Date();
        function p(n) { return (n < 10 ? '0' : '') + n; }
        logLines.push(d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds()) + ' ' + msg);
        if (logLines.length > 120) { logLines.shift(); }
        try { wf.cli('uimod.cfg_save', { mod_id: MOD, section: SAVED, key: 'log', value: logLines.join('\n') }); } catch (e) {}
    }
    function fail(what) { return function (err) { log(what + ': ' + ((err && err.message) || err)); }; }

    // ---- settings, remembered between sessions -----------------------------------------------
    var st = { needs: true, walk: true, dist: 6, camera: false, cameraPrev: '', attract: false, level: 0,
               flirt: true, accept: false, target: 'everyone', picked: {}, prefsOrig: {},
               pron: 'auto', pSubj: 'they', pObj: 'them' };
    function saveSettings() {
        try { wf.cli('uimod.cfg_save', { mod_id: MOD, section: SAVED, key: 'settings', value: JSON.stringify(st) }); } catch (e) {}
    }
    function loadSettings() {
        return run('uimod.cfg_load', { mod_id: MOD, section: SAVED, key: 'settings' }).then(function (res) {
            var raw = res && (res.value || (res.data && res.data.value));
            var saved = typeof raw === 'string' ? parseLoose(raw) : null;
            if (saved) { for (var k in saved) { if (saved.hasOwnProperty(k)) { st[k] = saved[k]; } } }
        }).catch(function () {});
    }

    // ---- who is being played ------------------------------------------------------------------------
    var me = { id: null, name: 'Your zoi', gender: 'Male', age: 'Youth' };
    function refreshMe() {
        return run('entity.get_possessed', {}).then(function (d) {
            var id = d && d.entity_id;
            if (!id) { return; }
            var changed = id !== me.id;
            me.id = id;
            return run('entity.get_character_info', { entity_id: String(id) }).then(function (c) {
                me.name = (c && (c.first_name || c.name)) || me.name;
                me.gender = (c && (c.bio_gender || c.gender)) || me.gender;
                me.age = (c && c.growth_step) || me.age;
                if (changed) { pushSettings(); }
            });
        }).catch(fail('who'));
    }
    // the player's pronouns: picked in the window, or taken from the zoi's gender
    function pro() {
        var mode = st.pron;
        if (mode === 'auto') { mode = me.gender === 'Female' ? 'she' : me.gender === 'Male' ? 'he' : 'custom'; }
        if (mode === 'he') { return { subj: 'he', obj: 'him' }; }
        if (mode === 'she') { return { subj: 'she', obj: 'her' }; }
        return { subj: String(st.pSubj || 'they').toLowerCase(), obj: String(st.pObj || 'them').toLowerCase() };
    }
    function pronoun() { return pro().obj; }
    function meGrown() { return !!GROWN[me.age]; }

    // ---- bus to the Lua side (a command file the game-thread Lua forwards) -------------------------
    var seq = new Date().getTime() % 1000000, queue = [], busy = false;
    function send(cmd) { queue.push(cmd); pump(); }
    function pump() {
        if (busy || !queue.length || !me.id) { return; }
        busy = true;
        seq += 1;
        var line = 'seq=' + seq + ';pid=' + me.id + ';' + queue.shift();
        try { wf.cli('uimod.cfg_save', { mod_id: MOD, section: 'bus', key: 'cmd', value: line }); } catch (e) {}
        setTimeout(function () { busy = false; pump(); }, 700);
    }
    function pushSettings() {
        send('op=settings;needs=' + (st.needs ? 1 : 0) + ';walk=' + (st.walk ? 1 : 0) + ';dist=' + st.dist +
             ';attract=' + (st.attract ? 1 : 0) + ';level=' + st.level + ';accept=' + (st.accept ? 1 : 0) + ';logdice=1');
    }
    // Mount this mod's Lua once. If it's already running (the window was reloaded), leave it alone:
    // a remount reloads every mounted Novulon mod's Lua, and doing that mid-game is what crashed the game.
    var luaAlive = false;
    function mountLua() {
        send('op=ping');
        setTimeout(function () {
            if (luaAlive) { log('lua already running'); pushSettings(); return; }
            run('luamod.mount', { mod_id: MOD }).then(function () { log('lua mounted'); }).catch(fail('lua mount'));
        }, 3500);
    }

    // ---- HUD button ---------------------------------------------------------------------------------
    var btn = document.getElementById('nv-btn');
    var win = document.getElementById('nv-win');
    var pop = document.getElementById('nv-pop');
    btn.appendChild(icon(ICON.brain));
    btn.addEventListener('click', function () { if (win.style.display === 'flex') { closeWin(); } else { openWin(); } });
    shell.addArea(btn, true);
    shell.addArea(win);
    shell.addArea(pop);

    // follow the game's bottom-right icon row, hide with the HUD
    // ---- one Novulon button ----------------------------------------------------------------------------------
    // With StatCheats installed, its N button is the hub: it lists this mod and opens it through shared/remote.
    // Alone, this mod keeps its own button.
    var hubAlive = false, lastRemote = null;
    function cfgGet(modId, key) {
        return run('uimod.cfg_load', { mod_id: modId, section: 'shared', key: key }).then(function (res) {
            return String((res && (res.value || (res.data && res.data.value))) || '');
        }).catch(function () { return ''; });
    }
    setInterval(function () {
        try {
            wf.cli('uimod.cfg_save', { mod_id: MOD, section: 'shared', key: 'menu',
                value: JSON.stringify({ label: 'AI Remade', sub: 'Behavior and attraction', alive: new Date().getTime() }) });
        } catch (e) {}
    }, 5000);
    setInterval(function () {
        cfgGet('NovulonStatCheats_WWPRTR', 'hub').then(function (v) {
            var alive = !!v && new Date().getTime() - Number(v) < 15000;
            if (alive !== hubAlive) { hubAlive = alive; placeButton(); }
        });
    }, 3000);
    setInterval(function () {
        cfgGet(MOD, 'remote').then(function (v) {
            if (lastRemote === null) { lastRemote = v; return; }      // ignore whatever was there at load
            if (!v || v === lastRemote) { return; }
            lastRemote = v;
            var parts = v.split('|'), cmd = parts[0];
            if (parts[2] === 'behavior' || parts[2] === 'attraction') { tab = parts[2]; }   // optional: 'open|ts|attraction'
            if (cmd === 'open') { if (win.style.display !== 'flex') { openWin(); } else { render(); } }
            if (cmd === 'close' && win.style.display === 'flex') { closeWin(); }
        });
    }, 700);

    function placeButton() {
        run('ui.find', { Window: 'Hud', Role: 'button', Limit: 200 }).then(function (list) {
            var items = (list && (list.length != null ? list : list.items)) || [];
            var left = null;
            items.forEach(function (it) {
                if (!it.rect || String(it.ref || '').indexOf('MenuEntryBox') < 0) { return; }
                if (left == null || it.rect[0] < left.rect[0]) { left = it; }
            });
            if (left) {
                btn.style.top = Math.round(left.rect[1] + left.rect[3] / 2 - 19) + 'px';
                btn.style.display = hubAlive ? 'none' : 'flex';   // StatCheats' N button opens this mod when it's installed
            } else {
                btn.style.display = 'none';
                if (win.style.display === 'flex') { closeWin(); }
            }
            shell.settle();
        }).catch(function () {});
    }

    // ---- the game's own side windows ------------------------------------------------------------------
    var HUD_TYPES = { Hud: 1, WaypointIndicator: 1, InteractionMarkerCanvas: 1, SpeechBubble: 1, CursorActorInfo: 1, RegionMessage: 1 };
    function sideWindows() {
        return run('ui.list_windows', {}).then(function (d) {
            var ws = (d && d.windows) || [];
            return ws.filter(function (w) {
                if (HUD_TYPES[w.ui_type]) { return false; }
                var r = w.rect || [0, 0, 1920, 1200];
                return r[2] < 1800 && r[0] + r[2] > 1300 && r[1] < 1140;
            });
        }).catch(function () { return []; });
    }
    function closeGameWindow(w) {
        return run('ui.find', { Window: w.window, Role: 'button', Limit: 60 }).then(function (list) {
            var items = (list && (list.length != null ? list : list.items)) || [];
            var best = null;
            items.forEach(function (it) {
                var name = String(it.ref || '') + ' ' + String(it.text || '');
                if (/close|exit/i.test(name)) { best = best || it; }
            });
            if (!best) {  // fall back to the small button nearest the top-right corner
                items.forEach(function (it) {
                    if (!it.rect || it.rect[2] > 60) { return; }
                    var score = it.rect[0] - it.rect[1];
                    if (!best || score > best.rect[0] - best.rect[1]) { best = it; }
                });
            }
            if (best) { return run('ui.click', { ref: best.ref }); }
        }).catch(fail('close game window'));
    }

    // Other Novulon windows: each one writes shared/open when it opens and closes itself when a newer one opens.
    var OTHER_MODS = ['NovulonStatCheats_WWPRTR'];
    function otherOpenedAfter(t) {
        return Promise.all(OTHER_MODS.map(function (id) {
            return run('uimod.cfg_load', { mod_id: id, section: 'shared', key: 'open' }).then(function (res) {
                return Number((res && (res.value || (res.data && res.data.value))) || 0);
            }).catch(function () { return 0; });
        })).then(function (times) { return times.some(function (x) { return x > t; }); });
    }

    var watchTimer = null, openedAt = 0, ticks = 0;
    function openWin() {
        sideWindows().then(function (ws) {
            return Promise.all(ws.map(closeGameWindow));
        }).then(function () {
            win.style.display = 'flex';
            btn.className = 'on';
            openedAt = new Date().getTime();
            try { wf.cli('uimod.cfg_save', { mod_id: MOD, section: 'shared', key: 'open', value: String(openedAt) }); } catch (e) {}
            render();
            shell.settle();
            if (watchTimer) { clearInterval(watchTimer); }
            ticks = 0;
            watchTimer = setInterval(function () {
                ticks += 1;
                otherOpenedAfter(openedAt).then(function (newer) { if (newer) { closeWin(); } });
                if (ticks % 2 || new Date().getTime() - openedAt < 1500) { return; }
                sideWindows().then(function (ws) { if (ws.length) { closeWin(); } });
            }, 700);
        });
    }
    function closeWin() {
        win.style.display = 'none';
        btn.className = '';
        if (watchTimer) { clearInterval(watchTimer); watchTimer = null; }
        shell.settle();
    }

    // ---- controls -----------------------------------------------------------------------------------------
    function toggle(on, onChange) {
        var t = el('div', 'tog' + (on ? ' on' : ''));
        t.appendChild(el('div', 'knob'));
        t.addEventListener('click', function () {
            on = !on;
            t.className = 'tog' + (on ? ' on' : '');
            onChange(on);
        });
        return t;
    }
    function card(title, desc, on, onChange) {
        var c = el('div', 'card' + (on === false ? ' off' : ''));
        var line = el('div', 'line');
        var texts = el('div', 'texts');
        texts.appendChild(el('div', 'title', title));
        texts.appendChild(el('div', 'desc', desc));
        line.appendChild(texts);
        if (onChange) {
            line.appendChild(toggle(on, function (v) {
                c.className = 'card' + (v ? '' : ' off');
                onChange(v);
            }));
        }
        c.appendChild(line);
        return c;
    }
    function chips(options, value, onPick) {
        var row = el('div', 'chips');
        options.forEach(function (o) {
            var ch = el('div', 'chip' + (o.value === value ? ' sel' : ''), o.label);
            ch.addEventListener('click', function () {
                Array.prototype.forEach.call(row.childNodes, function (n) { n.className = 'chip'; });
                ch.className = 'chip sel';
                onPick(o.value);
            });
            row.appendChild(ch);
        });
        return row;
    }
    function pill(text, cls, onClick) {
        var p = el('div', 'pill ' + cls, text);
        p.addEventListener('click', onClick);
        return p;
    }

    // ---- window -------------------------------------------------------------------------------------------------
    var tab = 'behavior';
    function render() {
        win.innerHTML = '';
        win.appendChild(el('div', 'topline'));
        win.appendChild(el('div', 'glow'));
        var head = el('div', 'win-head');
        var logo = el('img', 'logo');
        logo.setAttribute('src', 'logo.svg');
        head.appendChild(logo);
        var titles = el('div', 'win-titles');
        titles.appendChild(el('div', 'win-kicker', 'NOVULON'));
        titles.appendChild(el('div', 'win-title', 'AI Remade'));
        head.appendChild(titles);
        var x = el('div', 'x-btn');
        x.appendChild(icon(ICON.x));
        x.addEventListener('click', closeWin);
        head.appendChild(x);
        win.appendChild(head);

        var tabs = el('div', 'tabs');
        [{ id: 'behavior', label: 'Behavior' }, { id: 'attraction', label: 'Attraction' }].forEach(function (t) {
            var b = el('div', 'tab' + (t.id === tab ? ' sel' : ''), t.label);
            b.addEventListener('click', function () { tab = t.id; render(); });
            tabs.appendChild(b);
        });
        win.appendChild(tabs);

        var body = el('div', 'body');
        body.appendChild(tab === 'behavior' ? behaviorPage() : attractionPage());
        win.appendChild(body);

        var foot = el('div', 'foot');
        foot.appendChild(pill('Close', 'dark', closeWin));
        win.appendChild(foot);
    }

    function behaviorPage() {
        var page = el('div', 'page');
        page.appendChild(card('Ask before acting alone', 'Needs, chores and plans wait for your OK. A popup at the top asks first.', st.needs, function (v) {
            st.needs = v; saveSettings(); pushSettings();
        }));
        var walk = card('Walking away ends a talk', 'Walk off during a conversation to leave it.', st.walk, function (v) {
            st.walk = v; saveSettings(); pushSettings();
        });
        walk.appendChild(chips([{ label: '4 m', value: 4 }, { label: '6 m', value: 6 }, { label: '10 m', value: 10 }], st.dist, function (v) {
            st.dist = v; saveSettings(); pushSettings();
        }));
        page.appendChild(walk);

        var pc = card('Pronouns', 'Used in popups and in what zois say about ' + me.name + '.', null, null);
        var custom = el('div', 'line');
        custom.style.marginTop = '10px';
        var subj = el('input', 'search gapr'); subj.style.marginTop = '0px'; subj.value = st.pSubj; subj.setAttribute('placeholder', 'they');
        var obj = el('input', 'search'); obj.style.marginTop = '0px'; obj.value = st.pObj; obj.setAttribute('placeholder', 'them');
        function keep() {
            st.pSubj = String(subj.value || '').trim().slice(0, 12) || 'they';
            st.pObj = String(obj.value || '').trim().slice(0, 12) || 'them';
            saveSettings();
        }
        ['input', 'keyup', 'change'].forEach(function (ev) { subj.addEventListener(ev, keep); obj.addEventListener(ev, keep); });
        custom.appendChild(subj); custom.appendChild(obj);
        custom.style.display = st.pron === 'custom' ? 'flex' : 'none';
        pc.appendChild(chips([{ label: 'Auto', value: 'auto' }, { label: 'He/him', value: 'he' },
                              { label: 'She/her', value: 'she' }, { label: 'Custom', value: 'custom' }], st.pron, function (v) {
            st.pron = v; saveSettings();
            custom.style.display = v === 'custom' ? 'flex' : 'none';
            shell.settle();
        }));
        pc.appendChild(custom);
        page.appendChild(pc);
        return page;
    }

    function levelWord(v) {
        if (v <= -8) { return 'Seen as ugly'; }
        if (v <= -5) { return 'Unappealing'; }
        if (v <= -2) { return 'Plain'; }
        if (v < 0) { return 'A bit plain'; }
        if (v === 0) { return 'Normal'; }
        if (v <= 2) { return 'Cute'; }
        if (v <= 5) { return 'Attractive'; }
        if (v <= 8) { return 'Stunning'; }
        return 'Perfect';
    }
    function levelHint(v) {
        if (v >= 8) { return 'Adults nearby fall for you fast and rarely say no.'; }
        if (v >= 4) { return 'People notice you and come over to flirt.'; }
        if (v > 0) { return 'A little more interest than usual.'; }
        if (v === 0) { return 'The game decides, like normal.'; }
        if (v > -5) { return 'A little less interest than usual.'; }
        return 'Most people turn you down.';
    }

    function attractionPage() {
        var page = el('div', 'page');
        if (!meGrown()) {
            page.appendChild(card('Attraction', 'Only for young adults and older.', null, null));
            return page;
        }
        var main = card('Attraction', 'How other adults see ' + me.name + '.', st.attract, function (v) {
            st.attract = v; saveSettings(); pushSettings();
        });
        var level = el('div', 'level');
        var num = el('div', 'lv-num', (st.level > 0 ? '+' : '') + st.level);
        var texts = el('div', 'lv-texts');
        var word = el('div', 'lv-word', levelWord(st.level));
        var hint = el('div', 'lv-hint', levelHint(st.level));
        texts.appendChild(word); texts.appendChild(hint);
        var minus = el('div', 'step', '-'), plus = el('div', 'step', '+');
        level.appendChild(num); level.appendChild(texts); level.appendChild(minus); level.appendChild(plus);
        main.appendChild(level);

        var track = el('div', 'track');
        var fill = el('div', 'fill'), mid = el('div', 'mid'), knob = el('div', 'knob2');
        track.appendChild(fill); track.appendChild(mid); track.appendChild(knob);
        main.appendChild(track);
        var ends = el('div', 'ends');
        ends.appendChild(el('div', 'l', '-10 Seen as ugly'));
        ends.appendChild(el('div', null, '+10 Perfect'));
        main.appendChild(ends);
        var warn = el('div', 'warn');
        warn.appendChild(el('div', 'warn-mark', '!'));
        var warnText = el('div', 'warn-text', '');
        warn.appendChild(warnText);
        main.appendChild(warn);
        function showWarn(v) {
            if (v >= 7) { warnText.textContent = 'Zois will message and call ' + me.name + ' a lot at this level. Expect a flooded phone.'; }
            else if (v >= 3) { warnText.textContent = 'Zois will likely message ' + me.name + ' more often. The phone can fill up fast.'; }
            warn.style.display = v >= 3 ? 'flex' : 'none';
        }

        var TRACK_W = 340;  // card inner width minus the track margins
        function show(v) {
            num.textContent = (v > 0 ? '+' : '') + v;
            word.textContent = levelWord(v);
            hint.textContent = levelHint(v);
            showWarn(v);
            var x = Math.round((v + 10) / 20 * TRACK_W), c = Math.round(TRACK_W / 2);
            knob.style.left = x + 'px';
            fill.style.left = Math.min(x, c) + 'px';
            fill.style.width = Math.abs(x - c) + 'px';
            mid.style.left = (c - 1) + 'px';
        }
        function set(v) {
            v = Math.max(-10, Math.min(10, v));
            if (v === st.level) { return; }
            st.level = v; show(v); saveSettings(); pushSettings();
        }
        minus.addEventListener('click', function () { set(st.level - 1); });
        plus.addEventListener('click', function () { set(st.level + 1); });
        var dragging = false;
        function fromMouse(e) {
            var b = track.getBoundingClientRect();
            var ratio = Math.max(0, Math.min(1, (e.clientX - b.left) / b.width));
            var v = Math.round(ratio * 20 - 10);
            num.textContent = (v > 0 ? '+' : '') + v; word.textContent = levelWord(v); hint.textContent = levelHint(v); showWarn(v);
            var x = Math.round(ratio * TRACK_W), c = Math.round(TRACK_W / 2);
            knob.style.left = x + 'px'; fill.style.left = Math.min(x, c) + 'px'; fill.style.width = Math.abs(x - c) + 'px';
            return v;
        }
        track.addEventListener('mousedown', function (e) { dragging = true; fromMouse(e); });
        document.addEventListener('mousemove', function (e) { if (dragging) { fromMouse(e); } });
        document.addEventListener('mouseup', function (e) { if (dragging) { dragging = false; set(fromMouse(e)); show(st.level); } });
        show(st.level);
        page.appendChild(main);

        page.appendChild(card('They come to flirt', 'Adults nearby notice ' + me.name + ', walk over and flirt. More often at higher levels.', st.flirt, function (v) {
            st.flirt = v; saveSettings();
        }));
        page.appendChild(card('Always accept my invites', 'Calls, plans and visits get a yes. When off, the level sets the odds.', st.accept, function (v) {
            st.accept = v; saveSettings(); pushSettings();
        }));
        page.appendChild(prefsCard());
        return page;
    }

    // ---- preferences ----------------------------------------------------------------------------------------
    var city = null;   // adults in the city: [{id, name, gender, age}]
    function loadCity() {
        if (city) { return Promise.resolve(city); }
        var out = [];
        function page(offset) {
            return run('world.list_characters', { Limit: 100, Offset: offset }).then(function (d) {
                var list = (d && d.characters) || [];
                list.forEach(function (c) {
                    if (!GROWN[c.age_group] || c.entity_id === me.id) { return; }
                    out.push({ id: c.entity_id, name: c.first_name + ' ' + c.last_name, gender: c.gender, age: c.age_group_text || c.age_group });
                });
                if (list.length === 100 && offset < 2000) { return page(offset + 100); }
            });
        }
        return page(0).then(function () {
            out.sort(function (a, b) { return a.name < b.name ? -1 : 1; });
            city = out;
            return out;
        });
    }
    function chosenIds() {
        if (!city) { return []; }
        return city.filter(function (c) {
            if (st.target === 'everyone') { return true; }
            if (st.target === 'women') { return c.gender === 'Female'; }
            if (st.target === 'men') { return c.gender === 'Male'; }
            return !!st.picked[c.id];
        }).map(function (c) { return c.id; });
    }
    function genderCode() { return me.gender === 'Female' ? 2 : me.gender === 'Male' ? 1 : 3; }

    var prefsNote = null;
    function prefsCard() {
        var c = card('Make them into you', "Change who they're attracted to so they can fall for " + me.name + '. Adults only.', null, null);
        var listWrap = el('div');
        var pick = chips([{ label: 'Everyone', value: 'everyone' }, { label: 'Women', value: 'women' },
                          { label: 'Men', value: 'men' }, { label: 'Pick', value: 'pick' }], st.target, function (v) {
            st.target = v; saveSettings(); drawList();
        });
        c.appendChild(pick);
        c.appendChild(listWrap);
        prefsNote = el('div', 'note', '');
        var btns = el('div', 'btns');
        var lastApply = 0;
        var apply = pill('Apply', 'light small gapr', function () {
            var now = new Date().getTime();
            if (now - lastApply < 4000) { return; }   // one click is enough; the change takes a few seconds
            lastApply = now;
            loadCity().then(function () {
                var ids = chosenIds();
                if (!ids.length) { prefsNote.textContent = 'Nobody picked yet.'; return; }
                prefsNote.textContent = 'Changing ' + ids.length + ' zois...';
                for (var i = 0; i < ids.length; i += 60) {
                    send('op=prefs;mode=match;gender=' + genderCode() + ';ids=' + ids.slice(i, i + 60).join(','));
                }
            });
        });
        var undo = pill('Undo', 'dark small', function () {
            var entries = [];
            for (var k in st.prefsOrig) { if (st.prefsOrig.hasOwnProperty(k)) { entries.push(k + ':' + st.prefsOrig[k]); } }
            if (!entries.length) { prefsNote.textContent = 'Nothing to undo.'; return; }
            prefsNote.textContent = 'Putting ' + entries.length + ' zois back...';
            for (var i = 0; i < entries.length; i += 40) {
                send('op=prefs;mode=restore;orig=' + entries.slice(i, i + 40).join('|'));
            }
            st.prefsOrig = {}; saveSettings();
        });
        btns.appendChild(apply); btns.appendChild(undo);
        c.appendChild(btns);
        c.appendChild(prefsNote);
        var changedCount = Object.keys(st.prefsOrig).length;
        prefsNote.textContent = changedCount ? changedCount + ' zois are into ' + me.name + ' now. Undo puts them back.' : '';

        function drawList() {
            listWrap.innerHTML = '';
            if (st.target !== 'pick') { return; }
            var search = el('input', 'search');
            search.setAttribute('placeholder', 'Search adults in the city');
            var people = el('div', 'people');
            listWrap.appendChild(search);
            listWrap.appendChild(people);
            shell.settle();
            function fill() {
                people.innerHTML = '';
                var q = String(search.value || '').toLowerCase();
                var shown = 0;
                (city || []).forEach(function (p) {
                    if (q && p.name.toLowerCase().indexOf(q) < 0) { return; }
                    if (shown >= 200) { return; }
                    shown += 1;
                    var row = el('div', 'person');
                    var initials = p.name.split(' ').map(function (s) { return s.charAt(0); }).join('').slice(0, 2);
                    row.appendChild(el('div', 'face', initials));
                    row.appendChild(el('div', 'pname', p.name));
                    row.appendChild(el('div', 'pmeta', (p.gender === 'Female' ? 'Woman' : p.gender === 'Male' ? 'Man' : '') + ', ' + p.age));
                    var box = el('div', 'box' + (st.picked[p.id] ? ' on' : ''));
                    if (st.picked[p.id]) { box.appendChild(icon(ICON.check)); }
                    row.appendChild(box);
                    row.addEventListener('click', function () {
                        if (st.picked[p.id]) { delete st.picked[p.id]; } else { st.picked[p.id] = 1; }
                        box.className = 'box' + (st.picked[p.id] ? ' on' : '');
                        box.innerHTML = '';
                        if (st.picked[p.id]) { box.appendChild(icon(ICON.check)); }
                        saveSettings();
                    });
                    people.appendChild(row);
                });
                if (!shown) { people.appendChild(el('div', 'note', city ? 'No one found.' : 'Loading...')); }
            }
            search.addEventListener('input', fill);
            search.addEventListener('keyup', fill);
            loadCity().then(fill).catch(fail('city'));
            fill();
        }
        drawList();
        return c;
    }

    // ---- camera ------------------------------------------------------------------------------------------------
    var CAM = 'CameraCenterOffsetKeyboardShoulderView';
    function applyCamera() {
        if (st.camera) {
            run('settings.get', { Option: CAM }).then(function (d) {
                var cur = d && (d.value != null ? String(d.value) : '');
                if (cur && cur !== 'SlightlyRight' && cur !== '3') { st.cameraPrev = cur; saveSettings(); }
                return run('settings.set', { Option: CAM, Value: 'SlightlyRight' });
            }).catch(fail('camera'));
        } else if (st.cameraPrev) {
            run('settings.set', { Option: CAM, Value: st.cameraPrev }).catch(fail('camera'));
        }
    }

    // ---- needs button: what the controlled zoi wants, waiting for a click ---------------------------------------
    // Sits under the game's top toolbar. There is no "no": a need stays listed until it is handled, and the game's
    // own emergency actions (critical hunger, collapsing from tiredness) are never blocked.
    var NEED_KEYS = { hunger: 1, bathroom: 1, hygiene: 1, sleep: 1, plan: 1, invite: 1, work: 1 };
    var needs = {}, needOrder = [];
    var needBtn = document.getElementById('nv-needs');
    var needList = document.getElementById('nv-needs-list');
    shell.addArea(needBtn);
    shell.addArea(needList);
    function bagWords(bag) {
        return String(bag).replace(/^(Coop_|Co_)/, '').replace(/_(Start|Main|Sub|Begin)$/i, '').replace(/MoveTo_?/i, '')
            .replace(/_/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').replace(/\d+/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
    }
    function kindOf(bag, why) {
        var b = String(bag).toLowerCase(), o = pronoun();
        if (why === 'schedule') { return { key: 'plan', icon: 'walk', title: me.name + ' has somewhere to be', action: 'Go now' }; }
        if (why === 'work') { return { key: 'work', icon: 'walk', title: me.name + ' has work now', action: 'Go to work' }; }
        if (why === 'coop') { return { key: 'invite', icon: 'talk', title: me.name + ' got asked to join in', action: 'Join: ' + (bagWords(bag) || 'activity') }; }
        if (/eat|food|cook|meal|snack|fridge|kiosk|breakfast|lunch|dinner|omelet|coffee|drink|juice/.test(b)) { return { key: 'hunger', icon: 'food', title: me.name + ' is hungry', action: 'Send ' + o + ' to eat' }; }
        if (/toilet|urinal|pee/.test(b)) { return { key: 'bathroom', icon: 'drop', title: me.name + ' needs the bathroom', action: 'Let ' + o + ' go' }; }
        if (/shower|bath|washhand|wash|teeth|brush|sink/.test(b)) { return { key: 'hygiene', icon: 'drop', title: me.name + ' wants to freshen up', action: 'Let ' + o + ' wash up' }; }
        if (/sleep|nap|bed|rest|lie|pajama/.test(b)) { return { key: 'sleep', icon: 'moon', title: me.name + ' is tired', action: 'Let ' + o + ' rest' }; }
        if (/talk|chat|greet|call|social/.test(b)) { return { key: 'social', icon: 'talk', title: me.name + ' wants some company', action: 'Let ' + o + ' go chat' }; }
        if (/clean|dust|sweep|mop|dish|laundry|tidy|trash|wipe/.test(b)) { return { key: 'chores', icon: 'star', title: me.name + ' wants to tidy up', action: 'Let ' + o + ' clean' }; }
        if (/tv|game|play|dance|music|guitar|piano|book|read|computer|phone|swim|exercise/.test(b)) { return { key: 'fun', icon: 'star', title: me.name + ' is bored', action: 'Let ' + o + ' have fun' }; }
        return { key: 'other:' + b, icon: 'star', title: me.name + ' wants to ' + (bagWords(bag) || 'do something'), action: 'Let ' + o + ' do it' };
    }
    function onAsk(d) {
        log('caught ' + d.bag + ' (' + d.why + ') target=' + d.target + ' cancelled=' + d.cancelled);
        if (!st.needs || String(d.who) !== String(me.id)) { return; }
        var k = kindOf(d.bag, d.why);
        if (!NEED_KEYS[k.key] && d.why !== 'need') { return; }     // other wandering is just stopped
        var isNew = !needs[k.key];
        needs[k.key] = { kind: k, data: d, at: new Date().getTime() };
        if (isNew) { needOrder.push(k.key); log('need: ' + k.title); }
        drawNeeds(isNew);
    }
    function drawNeeds(pulse) {
        needOrder = needOrder.filter(function (k) { return !!needs[k]; });
        if (!needOrder.length) {
            needBtn.style.display = 'none'; needList.style.display = 'none'; shell.settle(); return;
        }
        needBtn.innerHTML = '';
        needOrder.slice(0, 4).forEach(function (k) {
            var ic = el('div', 'need-ic');
            ic.appendChild(icon(ICON[needs[k].kind.icon] || ICON.star));
            needBtn.appendChild(ic);
        });
        var n = needOrder.length;
        needBtn.appendChild(el('div', 'need-label', n === 1 ? needs[needOrder[0]].kind.title : me.name + ' needs ' + n + ' things'));
        needBtn.style.display = 'flex';
        if (pulse) {
            needBtn.className = '';
            setTimeout(function () { needBtn.className = 'pulse'; }, 20);
            setTimeout(function () { needBtn.className = ''; }, 1800);
        }
        if (needList.style.display === 'flex') { drawNeedList(); }
        shell.settle();
    }
    function drawNeedList() {
        needList.innerHTML = '';
        needOrder.forEach(function (k) {
            var item = needs[k];
            var row = el('div', 'need-row');
            var ic = el('div', 'pop-icon');
            ic.appendChild(icon(ICON[item.kind.icon] || ICON.star));
            row.appendChild(ic);
            var texts = el('div', 'pop-texts');
            texts.appendChild(el('div', 'pop-title', item.kind.title));
            texts.appendChild(el('div', 'pop-sub', item.kind.action));
            row.appendChild(texts);
            row.addEventListener('click', function () { fulfil(k); });
            needList.appendChild(row);
        });
        needList.style.display = 'flex';
        shell.settle();
    }
    needBtn.addEventListener('click', function () {
        if (needList.style.display === 'flex') { needList.style.display = 'none'; shell.settle(); } else { drawNeedList(); }
    });
    function fulfil(key) {
        var item = needs[key];
        if (!item) { return; }
        delete needs[key];
        var d = item.data;
        // let the game's own retry through for a bit, and start it right away where that works
        send('op=allow;bag=' + d.bag + ';secs=180');
        send('op=allow;why=' + d.why + ';secs=45');
        if (d.why !== 'schedule' && d.why !== 'work') {
            var p = { entity_id: String(d.who), interaction_bag_id: d.bag };
            if (d.target && d.target !== '-1' && d.target !== '0' && d.target !== String(d.who)) { p.target_entity_id = String(d.target); }
            run('interaction.execute', p).catch(fail('run ' + d.bag));
        }
        log('done: ' + item.kind.title);
        needList.style.display = 'none';
        drawNeeds(false);
    }
    // a need the zoi stopped asking about for a while has been taken care of some other way
    setInterval(function () {
        var now = new Date().getTime(), changed = false;
        for (var k in needs) { if (needs.hasOwnProperty(k) && now - needs[k].at > 4 * 60 * 1000) { delete needs[k]; changed = true; } }
        if (changed) { drawNeeds(false); }
    }, 20000);

    // short notes under the toolbar (no buttons)
    function drawPop(kind) {
        pop.innerHTML = '';
        var ic = el('div', 'pop-icon');
        ic.appendChild(icon(ICON[kind.icon] || ICON.star));
        pop.appendChild(ic);
        var texts = el('div', 'pop-texts');
        texts.appendChild(el('div', 'pop-title', kind.title));
        if (kind.sub) { texts.appendChild(el('div', 'pop-sub', kind.sub)); }
        pop.appendChild(texts);
        pop.style.display = 'flex';
        shell.settle();
    }
    function hidePop() { pop.style.display = 'none'; shell.settle(); }
    function flash(kind) {
        drawPop(kind);
        setTimeout(hidePop, 2500);
    }
    // ---- attraction: adults nearby notice the player ------------------------------------------------------------
    // "Into you" (0-100) is how much each adult is into the player. It grows while they see the player at a
    // positive level, shrinks at a negative one, lives in the save file, and raises their odds of saying yes.
    var into = {};
    try {
        inzoi.saveState.register(function () { return { into: into }; });
        inzoi.saveState.onLoad(function (json) {
            var s = parseLoose(json);
            if (s && s.into) { into = s.into; pushInto(true); }
        });
    } catch (e) { log('saveState: ' + e); }
    var sentInto = {};
    function pushInto(all) {
        var parts = [];
        for (var id in into) {
            if (!into.hasOwnProperty(id)) { continue; }
            var v = Math.round(into[id]);
            if (all || sentInto[id] !== v) { parts.push(id + ':' + v); sentInto[id] = v; }
        }
        for (var i = 0; i < parts.length; i += 80) { send('op=into;v=' + parts.slice(i, i + 80).join(',')); }
    }
    function addInto(id, delta) {
        var v = Math.max(0, Math.min(100, (into[id] || 0) + delta));
        if (v === 0) { delete into[id]; } else { into[id] = v; }
    }

    // what they do when they come over, by how strong the pull is
    var TIERS = [
        /Co_Romance_G04|Co_Romance_R0\d|Co_Ask_PhoneNumber|Co_Tease_|Compliment|Praise/,
        /HoldHands|KissForehead\w*Success|Co_Emotion_Enchanting|HugUp_\w*Success/,
        /DeepHug\w*Success|HugKiss|DeepKiss\w*Success|Lover_Sit_Peck|LoverHugDance/
    ];
    var NEVER = /Fail|Wedding|Serenade|TakePic|Coop_|teen|child|kid|infant|toddler|student|school/i;

    // lines over their heads; {name}, {subj} and {obj} follow the player's pronouns.
    // Opinions about the player only come from zois who already know them; strangers just notice.
    var LINES = {
        curious: ['Who is that?', 'Did {subj} just look at me?', 'Should I go say hi?', 'Wow.'],
        warm: ['{Name} looks good today.', 'Okay, {name} is cute.', 'I like {obj} already.', 'I wish I looked like that.'],
        hot: ["I can't take my eyes off {obj}.", "My heart won't stop racing.", "I think I'm falling for {name}.",
              'Please notice me...', "I'd do anything for {obj}.", 'Is {name} single?', 'I need to talk to {obj}. Now.',
              '{Name} is perfect.', 'Why is {name} so perfect?', "I'm too ugly for {name}.",
              '{Name} is way out of my league.', 'Someone like {obj} would never look at me.'],
        hello: ['Hey there...', 'I had to come say hi.', "You're even cuter up close.", "Hi. I couldn't stay away.",
                "I've been looking at you all day."],
        cold: ['Not my type.', "I'll pass.", 'Hm. No.', "{Name} isn't really my type."],
        harsh: ["Please don't come over here.", 'Yikes.', "I'm going to pretend I didn't see {obj}.", 'Nope. Not today.', 'Ew. No thanks.'],
        // only as a reaction when the player flirts with someone who knows them
        reject: ['{Name} is too ugly for me.', "{Subj}'s too ugly for me.", "Sorry, {name}. You're not my type.", 'Um... no.'],
        flustered: ["I'm too ugly for {name}.", 'Is this really happening?', "{Name}, you're making me blush."]
    };
    var known = {};    // zois with some relationship to the player
    function refreshKnown() {
        if (!me.id) { return; }
        run('relationships.list', { owner_id: String(me.id), min_value: 1 }).then(function (d) {
            known = {};
            ((d && d.relationships) || []).forEach(function (r) { known[r.target_id] = true; });
        }).catch(function () {});
    }
    // the player flirts: someone who knows them may react with a line (strangers keep their opinions to themselves)
    var FLIRTY = /Romance|Flirt|Tease|Compliment|Kiss|Hug|HoldHands|Ask_PhoneNumber|Enchanting/;
    function onStarted(d) {
        if (String(d.entity_id) !== String(me.id) || !d.target_entity_id || String(d.target_entity_id) === String(me.id)) { return; }
        var bag = String(d.interaction_bag_id || '');
        if (!FLIRTY.test(bag) || /Fail|Feedback/i.test(bag) || KIDS_WORDS.test(bag)) { return; }
        var id = d.target_entity_id;
        if (!known[id] || !meGrown() || !GROWN[ages[id]]) { return; }
        var L = st.attract ? st.level : 0, fondness = into[id] || 0;
        var rejectChance = 0.04 + Math.max(0, -L) * 0.05 + (fondness < 15 ? 0.08 : 0);
        if (Math.random() < rejectChance) { spoke[id] = 0; say(id, 'reject'); return; }
        if (fondness >= 70 && Math.random() < 0.25) { spoke[id] = 0; say(id, 'flustered'); }
    }
    var spoke = {};
    function fillLine(t) {
        var p = pro();
        var subjCap = p.subj.charAt(0).toUpperCase() + p.subj.slice(1);
        var s = t.replace(/\{Name\}/g, me.name).replace(/\{name\}/g, me.name).replace(/\{Subj\}/g, subjCap)
                 .replace(/\{subj\}/g, p.subj).replace(/\{obj\}/g, p.obj);
        return s.charAt(0).toUpperCase() + s.slice(1);
    }
    function say(id, kind) {
        var now = new Date().getTime();
        if (spoke[id] && now - spoke[id] < 40000) { return; }
        spoke[id] = now;
        var list = LINES[kind];
        run('entity.show_speech_bubble', { Text: fillLine(list[Math.floor(Math.random() * list.length)]), entity_id: String(id), duration: 5 })
            .catch(fail('bubble'));
    }

    function attractionTick() {
        if (!st.attract || !me.id || !meGrown() || st.level === 0) { return; }
        var L = st.level;
        run('entity.scan_characters', { Radius: L > 0 ? 20 : 10, Limit: 40, ref: 'pawn' }).then(function (d) {
            var near = ((d && d.characters) || []).filter(function (c) { return GROWN[c.age_group] && c.entity_id !== me.id; });
            if (L > 0) {
                var want = me.gender === 'Male' ? 'Female' : me.gender === 'Female' ? 'Male' : null;
                var pool = near.filter(function (c) { return !want || c.gender === want; });
                pool.forEach(function (c) { if (c.distance < 15) { addInto(c.entity_id, L * (0.4 + Math.random() * 0.6)); } });
                pool.slice(0, 6).forEach(function (c) {
                    if (Math.random() >= L / 14) { return; }
                    if (!known[c.entity_id]) { say(c.entity_id, 'curious'); return; }   // strangers only notice
                    say(c.entity_id, L >= 7 || (into[c.entity_id] || 0) >= 70 ? 'hot' : 'warm');
                });
                if (st.flirt && pool.length && Math.random() < L / 11) {
                    pool.sort(function (a, b) { return (into[b.entity_id] || 0) - (into[a.entity_id] || 0) || a.distance - b.distance; });
                    approach(pool[Math.floor(Math.random() * Math.min(pool.length, 3))], L);
                }
            } else {
                near.forEach(function (c) {
                    if (c.distance < 10) { addInto(c.entity_id, L * 1.5); }
                    if (known[c.entity_id] && c.distance < 10 && Math.random() < -L / 14) { say(c.entity_id, L <= -7 ? 'harsh' : 'cold'); }
                });
            }
            pushInto(false);
        }).catch(fail('attraction'));
    }
    function approach(npc, L) {
        var id = String(npc.entity_id);
        return run('interaction.get_current', { entity_id: id }).then(function (cur) {
            if (cur && cur.playing && String(cur.target_entity_id) === String(me.id)) { return; }   // already with the player
            var pull = Math.max(L * 10, into[npc.entity_id] || 0);
            var top = pull >= 80 ? 2 : pull >= 50 ? 1 : 0;
            if (L >= 6) { run('emotion.set', { entity_id: id, Type: 'Enchanting', Level: L >= 9 ? 2 : 1 }).catch(function () {}); }
            return run('interaction.list_available', { entity_id: id, target_entity_id: String(me.id) }).then(function (d) {
                var all = ((d && d.interactions) || []).filter(function (i) { return i.enabled !== false && !NEVER.test(i.interaction_bag_id); });
                var tier = Math.random() < 0.6 ? top : Math.floor(Math.random() * (top + 1));
                var list = [];
                for (var t = tier; t >= 0 && !list.length; t--) {
                    list = all.filter(function (i) { return TIERS[t].test(i.interaction_bag_id); });
                }
                if (!list.length) { log('flirt: nothing for ' + npc.first_name); return; }
                var pickIt = list[Math.floor(Math.random() * list.length)];
                log('flirt: ' + npc.first_name + ' -> ' + pickIt.interaction_bag_id);
                addInto(npc.entity_id, 4);
                say(npc.entity_id, 'hello');
                return run('interaction.execute', { entity_id: id, interaction_bag_id: pickIt.interaction_bag_id,
                                                    target_entity_id: String(me.id), insert_front: true });
            });
        }).catch(fail('approach'));
    }

    // ---- smarter zois (always on) ---------------------------------------------------------------------------------
    // Calm on purpose: a few social moments and lines around the player, never a crowd of them at once.
    var ages = {}, names = {}, friends = {}, busyUntil = 0, pairSeen = {};
    var GREET = /Co_Friendship_(G|B)04_Start\d?$|Co_Business_G04_Start\d?$/;
    var MOOD_LINES = {
        good: ['What a nice day.', 'I feel great today.', 'Life is good.', 'Mmm, I love this.'],
        bad: ['Sigh...', 'Not my day.', 'Ugh.', 'Can today be over already?'],
        hungry: ["I'm starving.", 'I need food. Now.', 'Is it lunchtime yet?'],
        tired: ['I need a nap.', 'I can barely keep my eyes open.', 'Bed. Soon.'],
        bored: ['So bored...', 'There has to be something to do.'],
        eat: ['So good.', 'I needed this.', 'Mmm.'],
        phone: ['Hold on...', 'One more scroll.', 'Who texted me?'],
        sit: ['Finally, a seat.', "Ahh, that's better."],
        walk: ['Almost there.', 'Where was I going again?']
    };
    function pick(list) { return list[Math.floor(Math.random() * list.length)]; }
    function bubble(id, text) {
        var now = new Date().getTime();
        if (spoke[id] && now - spoke[id] < 60000) { return; }
        spoke[id] = now;
        run('entity.show_speech_bubble', { Text: text, entity_id: String(id), duration: 5 }).catch(function () {});
    }
    function refreshFriends() {
        if (!me.id) { return; }
        run('relationships.list', { owner_id: String(me.id), min_value: 25 }).then(function (d) {
            friends = {};
            ((d && d.relationships) || []).forEach(function (r) { friends[r.target_id] = r.first_name; });
        }).catch(function () {});
    }
    function lineFor(c) {
        return run('interaction.get_current', { entity_id: String(c.entity_id) }).then(function (cur) {
            var bag = String((cur && cur.interaction_bag_id) || '').toLowerCase();
            if (bag.indexOf('talk') >= 0 || /romance|coop|co_/.test(bag)) { return null; }     // busy talking
            if (/eat|food|meal|snack|drink/.test(bag)) { return pick(MOOD_LINES.eat); }
            if (/phone|computer/.test(bag)) { return pick(MOOD_LINES.phone); }
            if (/sit/.test(bag)) { return pick(MOOD_LINES.sit); }
            if (cur && cur.action_type === 'WalkTo' && Math.random() < 0.3) { return pick(MOOD_LINES.walk); }
            return run('stat.get_all', { entity_id: String(c.entity_id) }).then(function (s) {
                var st2 = (s && s.stats) || {};
                if (st2.Hunger && st2.Hunger.pct < 20) { return pick(MOOD_LINES.hungry); }
                if (st2.Energy && st2.Energy.pct < 20) { return pick(MOOD_LINES.tired); }
                if (st2.Fun && st2.Fun.pct < 20) { return pick(MOOD_LINES.bored); }
                return run('emotion.get_current', { entity_id: String(c.entity_id) }).then(function (e) {
                    var tone = String((e && (e.tendency || e.emotion_type || e.emotion)) || '').toLowerCase();
                    if (/negative|sad|angry|annoy|stress|gloomy|upset/.test(tone)) { return pick(MOOD_LINES.bad); }
                    if (/positive|happy|excited|calm|funny|touch|confid/.test(tone)) { return pick(MOOD_LINES.good); }
                    return null;
                });
            });
        }).catch(function () { return null; });
    }
    function smartTick() {
        if (!me.id) { return; }
        run('entity.scan_characters', { Radius: 20, Limit: 40, ref: 'pawn' }).then(function (d) {
            var near = ((d && d.characters) || []).filter(function (c) { return c.entity_id !== me.id; });
            near.forEach(function (c) { ages[c.entity_id] = c.age_group; names[c.entity_id] = c.first_name; });
            var inView = near.filter(function (c) { return c.distance < 15; });
            if (inView.length && Math.random() < 0.6) {
                var c = inView[Math.floor(Math.random() * inView.length)];
                lineFor(c).then(function (text) { if (text) { bubble(c.entity_id, text); } });
            }
            near.forEach(function (c2) {
                if (friends[c2.entity_id] && c2.distance < 7 && Math.random() < 0.15) {
                    bubble(c2.entity_id, pick(['Hey ' + me.name + '!', 'Oh, hi ' + me.name + '.', 'Look who it is!', me.name + '! Good to see you.']));
                }
            });
        }).catch(fail('smart'));
    }
    // idle zois close together: space out the ones standing inside each other, and start the odd friendly chat
    function onPairs(d) {
        var now = new Date().getTime();
        String(d.v || '').split(';').forEach(function (e) {
            var p = e.split(':');
            var a = p[0], b = p[1], dist = Number(p[2]);
            if (!a || !b || a === String(me.id) || b === String(me.id)) { return; }
            var key = a < b ? a + '-' + b : b + '-' + a;
            if (pairSeen[key] && now - pairSeen[key] < 90000) { return; }
            var overlap = dist < 50;
            if (!overlap && (now < busyUntil || Math.random() > 0.12)) { return; }
            if (!ages[a] || !ages[b] || !!GROWN[ages[a]] !== !!GROWN[ages[b]]) { return; }   // same age band only
            pairSeen[key] = now;
            if (!overlap) { busyUntil = now + 15000; }
            run('interaction.list_available', { entity_id: a, target_entity_id: b }).then(function (r) {
                var list = ((r && r.interactions) || []).filter(function (i) { return i.enabled !== false && GREET.test(i.interaction_bag_id); });
                if (!list.length) { return; }
                var g = pick(list).interaction_bag_id;
                log((overlap ? 'space out: ' : 'chat: ') + (names[a] || a) + ' -> ' + (names[b] || b) + ' ' + g);
                return run('interaction.execute', { entity_id: a, interaction_bag_id: g, target_entity_id: b });
            }).catch(function () {});
        });
    }

    // ---- messages from the Lua side ----------------------------------------------------------------------------
    function on(name, fn) { try { inzoi.event.on(name, function (d) { try { fn(d || {}); } catch (e) { log(name + ' handler: ' + e); } }); } catch (e) { log('event ' + name + ': ' + e); } }
    on('lua_message.nv_hello', function () { log('lua ready'); pushSettings(); });
    on('lua_message.nv_state', function (d) { if (d.what === 'pong') { luaAlive = true; } log('lua ' + d.what + ' ' + (d.seq || '')); });
    on('lua_message.nv_ask', onAsk);
    on('lua_message.nv_info', function (d) {
        if (d.what === 'walked_away') { flash({ key: 'walk', icon: 'walk', title: 'Left the conversation', sub: 'Walked ' + d.meters + ' m away.' }); }
    });
    on('lua_message.nv_prefs', function (d) {
        if (d.mode === 'match') {
            String(d.orig || '').split('|').forEach(function (e) {
                var i = e.indexOf(':');
                if (i > 0 && !st.prefsOrig[e.slice(0, i)]) { st.prefsOrig[e.slice(0, i)] = e.slice(i + 1); }
            });
            saveSettings();
            if (prefsNote) { prefsNote.textContent = Object.keys(st.prefsOrig).length + ' zois are into ' + me.name + ' now. Undo puts them back.'; }
        } else if (prefsNote) {
            prefsNote.textContent = 'Back to how they were.';
        }
        log('prefs ' + d.mode + ' changed=' + d.changed + ' skipped=' + (d.skipped || 0));
    });
    on('lua_message.nv_err', function (d) { log('lua error in ' + d.where + ': ' + d.err); });
    on('lua_message.nv_pairs', onPairs);
    on('interaction.started', onStarted);
    on('lua_message.nv_seen', function (d) { log('seen ' + d.bag + ' reason=' + d.reason); });
    on('lua_message.nv_walk', function (d) { log('talking with ' + d.other + ' at ' + d.meters + ' m'); });
    on('lua_message.nv_phone', function (d) {
        log('phone ' + d.fn + ' sender=' + d.sender + ' receiver=' + d.receiver + ' was=' + d.was + ' now=' + d.now);
    });
    on('lua_message.nv_dice', function (d) {
        log('dice ' + d.fn + ' self=' + d.self + ' target=' + d.target + ' why=' + d.why + ' cmd=' + d.cmd +
            ' f1=' + d.f1 + ' f2=' + d.f2 + ' s1=' + d.s1 + ' s2=' + d.s2 + ' base=' + d.base + ' result=' + d.result);
    });

    // ---- start ---------------------------------------------------------------------------------------------------------
    log('hub up ' + window.innerWidth + 'x' + window.innerHeight);
    loadSettings().then(refreshMe).then(function () {
        mountLua();
        if (st.camera) { st.camera = false; saveSettings(); }   // the camera switch is gone: the game reloads to apply it
        placeButton();
    });
    setInterval(refreshMe, 5000);
    setInterval(placeButton, 3000);
    setInterval(attractionTick, 10000);
    setInterval(smartTick, 12000);
    setInterval(refreshFriends, 60000);
    setTimeout(refreshFriends, 3000);
    setInterval(refreshKnown, 60000);
    setTimeout(refreshKnown, 4000);
})();
