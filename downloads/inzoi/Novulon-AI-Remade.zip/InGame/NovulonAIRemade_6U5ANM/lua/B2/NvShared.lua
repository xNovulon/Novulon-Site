-- Novulon's AI Remade: state shared by every simulation-side script of this mod.
local S = {
    ic = {}, bio = {}, talk = {},            -- typed components by owner entity id (string)
    cfg = { needs = false, walkaway = false, walkDist = 6, attract = false, level = 0, accept = false, logDice = false },
    pid = nil,                               -- controlled zoi (string id)
    snooze = {}, asked = {},                 -- need key -> os.clock() deadline
    handle = nil,                            -- set by Main: handles commands from the window
}

local function esc(v)
    return (tostring(v):gsub('\\', '\\\\'):gsub('"', '\\"'):gsub('[%c]', ' '))
end

-- Send a flat table to the mod's window (arrives as the event 'lua_message.' .. kind).
function S.send(kind, fields)
    local parts = {}
    for k, v in pairs(fields or {}) do
        local t = type(v)
        if t == 'number' then parts[#parts + 1] = '"' .. k .. '":' .. tostring(v)
        elseif t == 'boolean' then parts[#parts + 1] = '"' .. k .. '":' .. (v and 'true' or 'false')
        else parts[#parts + 1] = '"' .. k .. '":"' .. esc(v) .. '"' end
    end
    pcall(function() inzoi.message.send_to_client(0, kind, '{' .. table.concat(parts, ',') .. '}') end)
end

function S.ownerId(comp)
    local ok, id = pcall(function() return comp:GetOwnerEntityId() end)
    if ok and id ~= nil then return tostring(id) end
    return nil
end

return S