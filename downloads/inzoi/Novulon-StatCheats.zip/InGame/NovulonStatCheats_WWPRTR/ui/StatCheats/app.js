/**
 * app.js -- Novulon's StatCheats.
 * An N button next to the HUD's bottom-right icon row opens a window in the game's own style: money, needs
 * and other stats, skills, relationships and mood, for the controlled zoi or anyone nearby. Right-clicking
 * the money readout opens a small Set / Add menu. Opening either closes the game's open side window, and
 * ours steps aside when the game opens one.
 */
(function () {
    'use strict';

    var run = nv.run;
    var $ = function (id) { return document.getElementById(id); };
    var nbtn = $('nbtn'), nbg = $('nbg'), nnotch = $('nnotch'), spot = $('money-spot'), tip = $('tip'), tipText = $('tip-text');
    var menu = $('money-menu'), win = $('win');

    var EXTRA_NAMES = { Weathering: 'Weather comfort', Homesick: 'Homesickness' };
    var REL = [
        { id: 'Romance', name: 'Love', color: '#ff4f9a' },
        { id: 'Friendship', name: 'Friendship', color: '#60a5fa' },
        { id: 'Business', name: 'Business', color: '#fbbf24' },
        { id: 'Family', name: 'Family', color: '#34d399' }
    ];
    var AGE_TEXT = { Youth: 'Young adult', Adult: 'Adult', Old: 'Elder', Elder: 'Elder', Elderly: 'Elder', Teen: 'Teen',
                     LowTeen: 'Teen', HighTeen: 'Teen', Child: 'Child', Toddler: 'Toddler', Baby: 'Baby', Infant: 'Baby' };
    var GOOD = '#34d399', MID = '#fbbf24', LOW = '#fb5471';   // Novulon ok / warn / danger

    var state = { me: null, target: null, people: [], tab: 'Money', hud: null };

    // ---------------- tiny DOM helpers (text always in its own element) ----------------
    function box(cls) { var e = document.createElement('div'); if (cls) { e.className = cls; } return e; }
    function txt(cls, text) { var e = box(cls); e.textContent = text == null ? '' : String(text); return e; }
    function show(e, on) { e.style.display = on ? 'flex' : 'none'; }
    function isOpen(e) { return e.style.display !== 'none'; }
    function add(parent) { for (var i = 1; i < arguments.length; i++) { if (arguments[i]) { parent.appendChild(arguments[i]); } } return parent; }
    function button(text, kind, onClick) {
        var b = box('btn' + (kind ? ' ' + kind : ''));
        b.appendChild(txt('btn-text', text));
        b.addEventListener('click', onClick);
        return b;
    }
    function gap() { return box('gap'); }
    function label(text, first) { return txt('label' + (first ? ' first' : ''), text.toUpperCase()); }
    function initials(name) {
        var p = String(name || '?').split(' ');
        return ((p[0] || '?').charAt(0) + (p[1] ? p[1].charAt(0) : '')).toUpperCase();
    }
    function face(name, small) { var f = box('face' + (small ? ' sm' : '')); f.appendChild(txt('face-text', initials(name))); return f; }
    function personById(id) { return state.people.filter(function (p) { return p.id === id; })[0]; }
    function xButton(onClick) {
        var x = box('xbtn');
        add(x, box('xline xa'), box('xline xb'));
        x.addEventListener('click', onClick);
        return x;
    }
    // gradient line, soft pink glow, the Novulon logo, title and close button
    function header(kicker, title, onClose, into) {
        into.appendChild(box('topline'));
        var h = box('head'), t = box('head-titles');
        var logo = document.createElement('img');
        logo.className = 'logo';
        logo.src = 'logo.svg';
        add(t, txt('kicker', kicker), txt('title', title));
        add(h, box('glow'), logo, t, xButton(onClose));
        into.appendChild(h);
    }

    // ---------------- placement next to the HUD ----------------
    var SLOT = 36;
    function findHud() {
        return run('ui.find', { Window: 'Hud', Role: 'button', Limit: 200 }).then(function (list) {
            list = Array.isArray(list) ? list : [];
            var row = list.filter(function (b) { return /MenuEntryBox/.test(b.ref || '') && b.rect; });
            if (!row.length) { return null; }
            row.sort(function (a, b) { return a.rect[0] - b.rect[0]; });
            var first = row[0].rect, last = row[row.length - 1].rect;
            var right = last[0] + last[2] + 6;   // the money readout is right-aligned just above the row
            return { first: first, last: last, money: [right - 140, last[1] - 40, 140, 26] };
        });
    }
    function layout() {
        return findHud().then(function (hud) {
            state.hud = hud;
            if (!hud) { show(nbtn, false); show(nbg, false); show(nnotch, false); show(spot, false); shell.settle(); return; }
            // The game's row is one frosted pill (top 4 px above the icons, 37 px tall, left edge 5 px before the
            // first icon). Our button gets a sibling pill of the same height, tint and rim just left of it. It can't
            // overlap the row: this view draws above the HUD and would dim the row's first icon.
            var f = hud.first, top = f[1] - 4, tall = f[3] + 7, pillLeft = f[0] - 5, w = 44, gapPx = 5;
            shell.place(nbg, shell.toView([pillLeft - gapPx - w, top, w, tall]));
            shell.place(nbtn, shell.toView([pillLeft - gapPx - w + (w - f[2]) / 2, f[1], f[2], f[3]]));
            shell.place(spot, shell.toView(hud.money));
            show(nbg, true); show(nnotch, false); show(nbtn, true); show(spot, true);
            placeWindows();
            shell.settle();
        }).catch(function (e) { nv.log('layout: ' + (e && e.message)); });
    }
    function placeWindows() {
        var hud = state.hud;
        if (!hud) { return; }
        var right = hud.last[0] + hud.last[2] + 8, bottom = hud.money[1] - 10;
        var w = 430, h = Math.min(640, bottom - 160);
        shell.place(win, shell.toView([right - w, bottom - h, w, h]));
        var mw = 320, mh = 380;
        shell.place(menu, shell.toView([right - mw, hud.money[1] - mh - 8, mw, mh]));
    }
    function showTip(text, anchor) {
        tipText.textContent = text;
        show(tip, true);
        var b = anchor.getBoundingClientRect();
        tip.style.left = Math.round(b.left + b.width / 2 - tip.offsetWidth / 2) + 'px';
        tip.style.top = Math.round(b.top - tip.offsetHeight - 10) + 'px';
    }
    function hideTip() { show(tip, false); }

    // ---------------- the game's own side windows ----------------
    // Windows that are always there (HUD, markers, bubbles, toasts) are left alone.
    var ALWAYS = /^(Hud)$|Canvas|Marker|Indicator|Bubble|Cursor|Toast|Region|Message|Notice|Loading|Minimap|KeyGuide/i;
    function sideWindows() {
        return run('ui.list_windows', {}).then(function (d) {
            return ((d && d.windows) || []).filter(function (w) {
                return w.ui_type && !ALWAYS.test(w.ui_type) && !ALWAYS.test(w.window || '') && w.counts && w.counts.interactive > 0;
            });
        }).catch(function () { return []; });
    }
    // Side panels such as Relationships live inside the Hud window; each has its own close button
    // (e.g. WBP_HUD_RelationshipList/BW_Button_Close). These close buttons are always there and aren't panels:
    var HUD_FIXTURES = /ShoulderViewControlGuide|PlayerDesire_List|WBP_HUD_Hope/;
    function hudPanels() {
        return run('ui.find', { Window: 'Hud', Role: 'button', Name: 'Close', Limit: 60 }).then(function (btns) {
            return (Array.isArray(btns) ? btns : []).filter(function (b) { return b.ref && !HUD_FIXTURES.test(b.ref); });
        }).catch(function () { return []; });
    }
    function closeGameWindows() {
        var panels = hudPanels().then(function (btns) {
            return Promise.all(btns.map(function (b) { return run('ui.click', { ref: b.ref, force: true }).catch(function () {}); }));
        });
        var windows = sideWindows().then(function (wins) {
            return Promise.all(wins.map(function (w) {
                return run('ui.find', { Window: w.ui_type, Role: 'button', Limit: 100 }).then(function (btns) {
                    var close = (Array.isArray(btns) ? btns : []).filter(function (b) { return /Close|Exit|Back/i.test(b.ref || ''); })[0];
                    if (close) { return run('ui.click', { ref: close.ref, force: true }); }
                }).catch(function () {});
            }));
        });
        return Promise.all([panels, windows]).then(function () { openedAt = Date.now(); });
    }
    // while ours is open, step aside the moment the game opens a panel or window
    var openedAt = 0, checking = false;
    setInterval(function () {
        if (checking || (!isOpen(win) && !isOpen(menu)) || Date.now() - openedAt < 1200) { return; }
        checking = true;
        Promise.all([hudPanels(), sideWindows(), otherModOpenedAt()]).then(function (r) {
            if (r[0].length || r[1].length || r[2] > ourOpenStamp) { closeWin(); closeMenu(); }
        }).then(function () { checking = false; }, function () { checking = false; });
    }, 450);

    // Novulon's other in-game mods: whichever window opened last stays, the others close.
    // Each mod writes Date.now() to its own cfg (section 'shared', key 'open') when its window opens.
    var OTHER_MODS = ['NovulonAIRemade_6U5ANM', 'NovulonLagRemover_PCTQ5Y'];
    var ourOpenStamp = 0;
    function announceOpen() {
        ourOpenStamp = Date.now();
        run('uimod.cfg_save', { mod_id: wf.MOD_ID, Section: 'shared', Key: 'open', Value: String(ourOpenStamp) }).catch(function () {});
    }
    function otherModOpenedAt() {
        return Promise.all(OTHER_MODS.map(function (id) {
            return run('uimod.cfg_load', { mod_id: id, Section: 'shared', Key: 'open' }).then(function (d) {
                return Number(d && (d.value != null ? d.value : d.Value)) || 0;
            }).catch(function () { return 0; });
        })).then(function (all) { return Math.max.apply(null, all.concat([0])); });
    }

    // ---------------- N button and main window ----------------
    nbtn.addEventListener('mouseenter', function () { showTip(others.length ? 'Novulon' : "Novulon's StatCheats", nbtn); });
    nbtn.addEventListener('mouseleave', hideTip);
    nbtn.addEventListener('click', function () {
        hideTip();
        if (isOpen(win)) { closeWin(); return; }
        if (!others.length) { openWin(); return; }            // StatCheats alone: straight to its window
        if (isOpen(chooser)) { closeChooser(); } else { openChooser(); }
    });

    // ---------------- one Novulon button for every Novulon mod ----------------
    // StatCheats is the hub: it says so every 5 s (shared/hub), and other Novulon mods hide their own button
    // while that is fresh. Each mod lists itself in its own shared/menu; picking it here writes the "open"
    // command where that mod listens (its menu entry can name the place, else shared/remote).
    var chooser = $('chooser');
    var others = [];
    var MOD_INFO = {
        NovulonAIRemade_6U5ANM: { label: 'AI Remade', sub: 'Behavior and attraction', icon: 'icon-airemade.svg' },
        NovulonLagRemover_PCTQ5Y: { label: 'Lag Remover', sub: 'Smoother frames', icon: 'icon-lagremover.svg' }
    };
    function heartbeat() {
        var now = String(Date.now());
        run('uimod.cfg_save', { mod_id: wf.MOD_ID, Section: 'shared', Key: 'hub', Value: now }).catch(function () {});
        run('uimod.cfg_save', { mod_id: wf.MOD_ID, Section: 'shared', Key: 'menu',
            Value: JSON.stringify({ label: 'StatCheats', sub: 'Money, needs, skills, relationships', alive: Number(now) }) }).catch(function () {});
        Promise.all(OTHER_MODS.map(function (id) {
            return run('uimod.cfg_load', { mod_id: id, Section: 'shared', Key: 'menu' }).then(function (d) {
                var raw = d && (d.value != null ? d.value : d.Value);
                if (!raw) { return null; }
                var m = nv.parseLoose(String(raw)) || {};
                if (m.alive && Date.now() - Number(m.alive) > 15000) { return null; }   // listed but not running
                var info = MOD_INFO[id] || {};
                return { id: id, label: m.label || info.label || id, sub: m.sub || info.sub || '', icon: info.icon || 'logo.svg',
                         section: m.section || 'shared', key: m.key || 'remote' };
            }).catch(function () { return null; });
        })).then(function (list) { others = list.filter(Boolean); });
    }
    heartbeat();
    setInterval(heartbeat, 5000);

    function openChooser() {
        chooser.innerHTML = '';
        var hud = state.hud;
        var w = 330, h = 96 + 60 * (others.length + 1);
        var bx = nbtn.getBoundingClientRect();
        shell.place(chooser, { x: Math.max(8, bx.left + bx.width - w + 40), y: bx.top - h - 12, w: w, h: h });
        header('NOVULON', 'Mods', closeChooser, chooser);
        var body = box('ch-body');
        function entry(icon, label, sub, fn) {
            var it = box('ch-item'), img = document.createElement('img'), texts = box('ch-texts');
            img.className = 'ch-icon'; img.src = icon;
            add(texts, txt('ch-name', label), txt('ch-sub', sub));
            add(it, img, texts, txt('ch-go', 'Open'));
            it.addEventListener('click', fn);
            body.appendChild(it);
        }
        entry('icon-statcheats.svg', 'StatCheats', 'Money, needs, skills, relationships', function () { closeChooser(); openWin(); });
        others.forEach(function (o) {
            entry(o.icon, o.label, o.sub, function () {
                closeChooser();
                run('uimod.cfg_save', { mod_id: o.id, Section: o.section, Key: o.key, Value: 'open|' + Date.now() }).catch(fail(o.label));
            });
        });
        chooser.appendChild(body);
        show(chooser, true);
        shell.settle();
    }
    function closeChooser() { show(chooser, false); shell.settle(); }

    function openWin() {
        hideTip();
        closeMenu();
        closeGameWindows().then(function () {
            announceOpen();
            placeWindows();
            show(win, true);
            showMain();
            loadPeople().catch(fail('Start'));
            shell.settle();
        });
    }
    function closeWin() { show(win, false); shell.settle(); }

    var main = box('main'), pick = box('pick');
    var who = box('who'), whoTexts = box('who-texts'), whoName = txt('who-name', '...'), whoSub = txt('who-sub', '');
    var whoFace = face('?');
    var change = box('change'); change.appendChild(txt('change-text', 'Change'));
    add(whoTexts, whoName, whoSub);
    add(who, whoFace, whoTexts, change);
    who.addEventListener('click', function () { openPicker(null); });

    var TABS = [['Money', 'Money'], ['Needs', 'Needs'], ['Skills', 'Skills'], ['Relationships', 'Relations'], ['Mood', 'Mood']];
    var tabs = box('tabs');
    TABS.forEach(function (t) {
        var b = box('tab');
        b.setAttribute('data-tab', t[0]);
        b.appendChild(txt('tab-text', t[1]));
        b.addEventListener('click', function () { state.tab = t[0]; drawTab(); });
        tabs.appendChild(b);
    });
    var page = box('scroll');
    add(main, who, tabs, page);

    var foot = box('foot'), toast = txt('toast', '');
    foot.appendChild(toast);
    header('NOVULON', 'StatCheats', closeWin, win);
    add(win, main, pick, foot);
    show(pick, false);

    var toastTimer = null;
    function say(text, bad) {
        toast.textContent = text || '';
        toast.className = 'toast' + (bad ? ' bad' : '');
        if (toastTimer) { clearTimeout(toastTimer); }
        if (text) { toastTimer = setTimeout(function () { toast.textContent = ''; }, 4000); }
    }
    function fail(what) {
        return function (err) {
            var msg = (err && err.message) || String(err);
            nv.log(what + ': ' + msg);
            if (/not lovable/i.test(msg)) { msg = 'the game doesn\'t allow love between these two.'; }
            else if (/not family/i.test(msg)) { msg = 'they aren\'t family.'; }
            say(what + ': ' + msg, true);
        };
    }
    function showMain() { show(pick, false); show(main, true); }

    // ---------------- people ----------------
    function loadPeople() {
        return Promise.all([
            run('entity.get_possessed', {}),
            nv.household().catch(function () { return { members: [] }; }),
            run('entity.scan_characters', { Radius: 80, Limit: 40, ref: 'pawn' }).catch(function () { return { characters: [] }; })
        ]).then(function (r) {
            state.me = r[0] && r[0].entity_id;
            var seen = {}, people = [];
            function addP(p, tag) {
                if (p.entity_id == null || seen[p.entity_id]) { return; }
                seen[p.entity_id] = true;
                people.push({ id: p.entity_id, name: p.first_name + ' ' + p.last_name, age: p.age_group,
                              tag: p.entity_id === state.me ? 'You' : tag, dist: p.distance });
            }
            ((r[1] && r[1].members) || []).forEach(function (p) { addP(p, 'Household'); });
            ((r[2] && r[2].characters) || []).forEach(function (p) { addP(p, 'Nearby'); });
            state.people = people;
            if (!state.target || !seen[state.target]) { state.target = state.me; }
            drawWho();
            drawTab();
        });
    }
    function drawWho() {
        var p = personById(state.target) || { name: 'Zoi', age: '', tag: '' };
        whoFace.firstChild.textContent = initials(p.name);
        whoName.textContent = p.name;
        var bits = [p.tag === 'You' ? 'Controlled zoi' : p.tag, AGE_TEXT[p.age] || ''].filter(Boolean);
        whoSub.textContent = bits.join(', ');
    }

    // "Choose Zoi": replaces the main view while open (no overlay on top of it)
    function openPicker(onPick) {
        pick.innerHTML = '';
        var search = box('search');
        var input = document.createElement('input');
        input.setAttribute('placeholder', 'Search');
        add(search, txt('kicker', 'FIND'), input);
        var filters = box('tabs'), filter = 'Everyone';
        ['Everyone', 'Household', 'Nearby'].forEach(function (name) {
            var f = box('tab' + (name === filter ? ' on' : ''));
            f.appendChild(txt('tab-text', name));
            f.addEventListener('click', function () {
                filter = name;
                Array.prototype.forEach.call(filters.children, function (c) { c.className = 'tab' + (c.textContent === name ? ' on' : ''); });
                draw();
            });
            filters.appendChild(f);
        });
        var list = box('scroll');
        var back = box('row');
        back.style.marginBottom = '10px';
        add(back, button('Back', 'glass sm', showMain));
        add(pick, back, search, filters, list);
        show(main, false);
        show(pick, true);
        input.addEventListener('input', draw);
        function draw() {
            var q = String(input.value || '').trim().toLowerCase();
            list.innerHTML = '';
            var rows = state.people.filter(function (p) {
                if (onPick && p.id === state.target) { return false; }
                if (filter === 'Household' && p.tag === 'Nearby') { return false; }
                if (filter === 'Nearby' && p.tag !== 'Nearby') { return false; }
                return !q || p.name.toLowerCase().indexOf(q) >= 0;
            });
            if (!rows.length) { list.appendChild(txt('empty', 'Nobody here.')); }
            rows.forEach(function (p) {
                var row = box('person' + (!onPick && p.id === state.target ? ' on' : ''));
                var tag = p.tag === 'Nearby' && p.dist != null ? Math.round(p.dist) + ' m away' : p.tag;
                add(row, face(p.name, true), txt('person-name', p.name), txt('person-tag', tag));
                row.addEventListener('click', function () {
                    showMain();
                    if (onPick) { onPick(p); return; }
                    state.target = p.id;
                    drawWho();
                    drawTab();
                });
                list.appendChild(row);
            });
        }
        draw();
    }

    function drawTab() {
        Array.prototype.forEach.call(tabs.children, function (t) {
            t.className = 'tab' + (t.getAttribute('data-tab') === state.tab ? ' on' : '');
        });
        page.innerHTML = '';
        say('');
        ({ Money: moneyTab, Needs: needsTab, Skills: skillsTab, Relationships: relTab, Mood: moodTab })[state.tab]();
    }

    // ---------------- drag bar ----------------
    function makeBar(min, max, value, color, onCommit, centered) {
        var bar = box('bar'), fill = box('bar-fill'), knob = box('bar-knob');
        add(bar, box('bar-track'), fill);
        if (centered) { var z = box('bar-zero'); z.style.left = '50%'; bar.appendChild(z); }
        bar.appendChild(knob);
        var hooks = [], cur = value, dragging = false;
        function frac(v) { return (Math.max(min, Math.min(max, v)) - min) / (max - min); }
        function draw(v) {
            var f = frac(v), c = centered ? frac(0) : 0;
            fill.style.left = (Math.min(f, c) * 100) + '%';
            fill.style.width = (Math.abs(f - c) * 100) + '%';
            fill.style.background = color(v);
            knob.style.left = (f * 100) + '%';
            knob.style.marginLeft = '-8px';
            hooks.forEach(function (fn) { fn(v); });
        }
        function valueAt(x) {
            var r = bar.getBoundingClientRect();
            return Math.round(min + Math.max(0, Math.min(1, (x - r.left) / r.width)) * (max - min));
        }
        bar.addEventListener('mousedown', function (e) { if (e.button === 0) { dragging = true; cur = valueAt(e.clientX); draw(cur); } });
        document.addEventListener('mousemove', function (e) { if (dragging) { cur = valueAt(e.clientX); draw(cur); } });
        document.addEventListener('mouseup', function () { if (dragging) { dragging = false; onCommit(cur); } });
        bar.set = function (v) { cur = v; draw(v); };
        bar.onDraw = function (fn) { hooks.push(fn); fn(cur); };
        draw(value);
        return bar;
    }
    function needColor(min, max) {
        return function (v) { var p = (v - min) / (max - min); return p < 0.3 ? LOW : p < 0.6 ? MID : GOOD; };
    }

    // ---------------- Money ----------------
    function moneyTab() {
        var bank = box('bank'), num = txt('bank-num', '...');
        add(bank, txt('kicker', 'HOUSEHOLD MONEY'), num);
        page.appendChild(bank);
        moneyControls(page, function (m) { num.textContent = nv.fmtMoney(m); }, say, fail);
        page.appendChild(label('Tip'));
        page.appendChild(txt('who-sub', 'Right-click the money above the icon row for a quick menu.'));
    }
    function moneyControls(into, showMoney, tell, onFail) {
        function refresh() { return nv.getMoney().then(showMoney).catch(onFail('Money')); }
        into.appendChild(label('Amount'));
        var field = box('field'), input = document.createElement('input');
        input.setAttribute('placeholder', 'Type an amount');
        field.appendChild(input);
        into.appendChild(field);
        function amount() {
            var n = Math.round(Number(String(input.value || '').replace(/[, ]/g, '')));
            if (!isFinite(n) || String(input.value || '').trim() === '') { tell('Type an amount first.', true); return null; }
            return n;
        }
        var row = box('row'); row.style.marginTop = '8px';
        var setB = button('Set to this', 'grow', function () {
            var n = amount(); if (n == null) { return; }
            n = Math.max(0, n);
            nv.setMoney(n).then(refresh).then(function () { tell('Money set to ' + nv.fmtMoney(n) + '.'); }).catch(onFail('Money'));
        });
        var addB = button('Add this', 'glass grow', function () {
            var n = amount(); if (n == null) { return; }
            nv.addMoney(n).then(refresh).then(function () { tell((n < 0 ? 'Took away ' : 'Added ') + nv.fmtMoney(Math.abs(n)) + '.'); }).catch(onFail('Money'));
        });
        add(row, setB, gap(), addB);
        into.appendChild(row);
        into.appendChild(label('Quick add'));
        var quick = box('row');
        [1000, 10000, 100000, 1000000].forEach(function (n, i) {
            if (i) { quick.appendChild(gap()); }
            quick.appendChild(button('+' + (n >= 1000000 ? '1M' : (n / 1000) + 'K'), 'glass sm grow', function () {
                nv.addMoney(n).then(refresh).then(function () { tell('Added ' + nv.fmtMoney(n) + '.'); }).catch(onFail('Money'));
            }));
        });
        into.appendChild(quick);
        refresh();
    }

    // ---------------- Needs and other stats ----------------
    function needsTab() {
        var row = box('row'), frozen = false;
        var freezeB = button('Freeze needs', 'glass grow', function () {
            frozen = !frozen;
            run('needs.freeze_all', { entity_id: String(state.target), Enable: frozen }).then(function () {
                freezeB.firstChild.textContent = frozen ? 'Unfreeze needs' : 'Freeze needs';
                say(frozen ? 'Needs frozen.' : 'Needs unfrozen.');
            }).catch(fail('Freeze'));
        });
        add(row, button('Fill all needs', 'grow', function () {
            run('needs.set_full', { entity_id: String(state.target) }).then(function () { say('Needs filled.'); load(); }).catch(fail('Needs'));
        }), gap(), freezeB);
        page.appendChild(row);
        var list = box(''); list.style.display = 'flex'; list.style.flexDirection = 'column'; list.style.marginTop = '10px';
        page.appendChild(list);
        function load() {
            run('stat.get_all', { entity_id: String(state.target) }).then(function (d) {
                list.innerHTML = '';
                var names = (d && d.stat_names) || {}, stats = (d && d.stats) || {};
                Object.keys(stats).forEach(function (id) {
                    var s = stats[id], name = names[id] || EXTRA_NAMES[id] || id;
                    var item = box('item'), head = box('item-head'), val = txt('item-val', '');
                    var maxB = button('Max', 'glass sm', function () {
                        run('stat.set', { entity_id: String(state.target), stat_id: id, Value: s.max })
                            .then(function () { bar.set(s.max); say(name + ' maxed.'); }).catch(fail(name));
                    });
                    add(head, txt('item-name', name), val, maxB);
                    var bar = makeBar(s.min, s.max, s.value, needColor(s.min, s.max), function (v) {
                        run('stat.set', { entity_id: String(state.target), stat_id: id, Value: v })
                            .then(function () { say(name + ' set.'); }).catch(fail(name));
                    });
                    bar.onDraw(function (v) { val.textContent = Math.round((v - s.min) / (s.max - s.min) * 100) + '%'; });
                    add(item, head, bar);
                    list.appendChild(item);
                });
            }).catch(fail('Stats'));
        }
        load();
    }

    // ---------------- Skills ----------------
    function skillsTab() {
        run('skill.get_all', { entity_id: String(state.target) }).then(function (d) {
            var all = (d && d.skills) || [], setters = [];
            var top = box('row');
            add(top, button('Max every skill', 'grow', function () {
                Promise.all(setters.map(function (s) { return s(); })).then(function () { say('Every skill maxed.'); }).catch(fail('Skills'));
            }));
            page.appendChild(top);
            var list = box(''); list.style.display = 'flex'; list.style.flexDirection = 'column'; list.style.marginTop = '10px';
            page.appendChild(list);
            all.forEach(function (s) {
                var item = box('item'), head = box('item-head'), val = txt('item-val', '');
                add(head, txt('item-name', s.l10n || s.id), val);
                var dots = box('dots');
                function draw() {
                    Array.prototype.forEach.call(dots.children, function (dd, i) { dd.className = 'dot' + (i < s.level ? ' on' : ''); });
                    val.textContent = 'Level ' + s.level + ' of ' + s.max_level;
                }
                function setLevel(n) {
                    n = Math.max(0, Math.min(s.max_level, n));
                    return run('skill.set_level', { entity_id: String(state.target), skill_id: s.id, Level: n }).then(function () { s.level = n; draw(); });
                }
                for (var i = 1; i <= s.max_level; i++) {
                    (function (lv) {
                        var dd = box('dot');
                        // clicking the top filled dot takes one level off, so 0 is reachable
                        dd.addEventListener('click', function () { setLevel(lv === s.level ? lv - 1 : lv).catch(fail(s.l10n || s.id)); });
                        dots.appendChild(dd);
                    })(i);
                }
                setters.push(function () { return setLevel(s.max_level); });
                add(item, head, dots);
                list.appendChild(item);
                draw();
            });
        }).catch(fail('Skills'));
    }

    // ---------------- Relationships ----------------
    function relTab() {
        var top = box('row');
        add(top, button('Add someone', 'glass grow', function () {
            openPicker(function (p) { card(p.id, p.name, null, p.age, true); });
        }));
        page.appendChild(top);
        var list = box(''); list.style.display = 'flex'; list.style.flexDirection = 'column'; list.style.marginTop = '10px';
        page.appendChild(list);
        var me = personById(state.target) || {}, shownIds = {};

        function card(id, name, stats, age, first, isFamily) {
            if (id === state.target || shownIds[id]) { return; }
            shownIds[id] = true;
            var c = box('card'), head = box('card-head');
            add(head, face(name, true), txt('card-name', name));
            c.appendChild(head);
            if (first && list.firstChild) { list.insertBefore(c, list.firstChild); } else { list.appendChild(c); }
            var valuesP = stats ? Promise.resolve({ stats: stats })
                : run('relationships.get_value_between', { owner_id: String(state.target), target_id: String(id) });
            var ageP = age ? Promise.resolve(age)
                : run('entity.get_character_info', { entity_id: String(id) }).then(function (i) { return i && i.growth_step; }).catch(function () { return null; });
            Promise.all([valuesP, ageP]).then(function (r) {
                var st = (r[0] && r[0].stats) || {};
                var lovable = nv.isGrown(me.age) && nv.isGrown(r[1]);   // love only between adults
                var bars = [];
                var family = isFamily || (st.Family && st.Family.value !== 0);
                REL.forEach(function (k) {
                    if (k.id === 'Romance' && !lovable) { return; }
                    if (k.id === 'Family' && !family) { return; }   // the game only changes this between relatives
                    var line = box('rel'), dot = box('rel-dot'), v = txt('rel-val', '');
                    dot.style.background = k.color;
                    var bar = makeBar(-100, 100, st[k.id] ? st[k.id].value : 0, function () { return k.color; }, function (val) {
                        run('relationships.set_value_between', { owner_id: String(state.target), target_id: String(id), relationship_id: k.id, Value: val })
                            .then(function () { say(k.name + ' with ' + name + ' set.'); }).catch(fail(k.name));
                    }, true);
                    bar.onDraw(function (val) { v.textContent = String(Math.round(val)); });
                    add(line, dot, txt('rel-name', k.name), bar, v);
                    c.appendChild(line);
                    bars.push({ k: k, bar: bar });
                });
                var acts = box('row'); acts.style.marginTop = '10px';
                add(acts, button('Best friends', 'glass sm grow', function () { setAll({ Friendship: 100 }); }));
                if (lovable) { add(acts, gap(), button('Soulmates', 'glass sm grow', function () { setAll({ Romance: 100, Friendship: 100 }); })); }
                add(acts, gap(), button('Strangers', 'glass sm grow', function () { setAll({ Romance: 0, Friendship: 0, Business: 0 }); }));
                c.appendChild(acts);
                function setAll(values) {
                    Promise.all(bars.filter(function (b) { return values[b.k.id] != null; }).map(function (b) {
                        return run('relationships.set_value_between', { owner_id: String(state.target), target_id: String(id),
                                                                        relationship_id: b.k.id, Value: values[b.k.id] })
                            .then(function () { b.bar.set(values[b.k.id]); });
                    })).then(function () { say('Done with ' + name + '.'); }).catch(fail('Relationship'));
                }
            }).catch(fail('Relationship'));
        }

        run('relationships.list', { owner_id: String(state.target), min_value: 1 }).then(function (d) {
            var rels = (d && d.relationships) || [];
            if (!rels.length) { list.appendChild(txt('empty', 'No relationships yet. Use Add someone.')); }
            rels.forEach(function (r) {
                var known = personById(r.target_id);
                card(r.target_id, r.first_name + ' ' + r.last_name, r.stats, known && known.age, false, r.is_family);
            });
        }).catch(fail('Relationships'));
    }

    // ---------------- Mood ----------------
    function moodTab() {
        var TONE = { positive: GOOD, negative: LOW, neutral: '#a39bb2' };
        run('emotion.list_all', {}).then(function (d) {
            var groups = { positive: [], negative: [], neutral: [] };
            ((d && d.emotions) || []).forEach(function (e) {
                if (e.id === 'Sleep') { return; }
                (e.levels && e.levels.length ? e.levels : [{ level: 1, l10n: e.id }]).forEach(function (lv) {
                    (groups[e.tendency] || groups.neutral).push({ id: e.id, level: lv.level, name: lv.l10n });
                });
            });
            var firstLabel = true;
            [['positive', 'Good moods'], ['negative', 'Bad moods'], ['neutral', 'Other']].forEach(function (g) {
                var items = groups[g[0]];
                if (!items.length) { return; }
                page.appendChild(label(g[1], firstLabel)); firstLabel = false;
                for (var i = 0; i < items.length; i += 3) {       // rows of three, no wrapping needed
                    var row = box('row'); row.style.marginBottom = '6px';
                    for (var j = i; j < i + 3; j++) {
                        var m = items[j], chip = box('mood' + (j === i + 2 ? ' end' : '') + (m ? '' : ' blank'));
                        if (m) {
                            var dot = box('mood-dot'); dot.style.background = TONE[g[0]];
                            add(chip, dot, txt('mood-text', m.name));
                            (function (mm) {
                                chip.addEventListener('click', function () {
                                    run('emotion.set', { entity_id: String(state.target), Type: mm.id, Level: mm.level })
                                        .then(function () { say('Mood set to ' + mm.name + '.'); }).catch(fail('Mood'));
                                });
                            })(m);
                        }
                        row.appendChild(chip);
                    }
                    page.appendChild(row);
                }
            });
        }).catch(fail('Mood'));
    }

    // ---------------- right-click money menu ----------------
    spot.addEventListener('mouseenter', function () { showTip('Right-click to change money', spot); });
    spot.addEventListener('mouseleave', hideTip);
    spot.addEventListener('mousedown', function (e) {
        if (e.button !== 2) { return; }
        e.preventDefault();
        hideTip();
        if (isOpen(menu)) { closeMenu(); return; }
        closeWin();
        closeGameWindows().then(function () {
            announceOpen();
            buildMenu();
            placeWindows();
            show(menu, true);
            shell.settle();
        });
    });
    spot.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    function closeMenu() { show(menu, false); shell.settle(); }
    function buildMenu() {
        menu.innerHTML = '';
        var body = box('main'), num = txt('bank-num', '...'), note = txt('toast', '');
        num.style.fontSize = '26px';
        var bank = box('bank');
        add(bank, txt('kicker', 'HOUSEHOLD MONEY'), num);
        body.appendChild(bank);
        moneyControls(body, function (m) { num.textContent = nv.fmtMoney(m); }, function (text, bad) {
            note.textContent = text; note.className = 'toast' + (bad ? ' bad' : '');
        }, function (what) { return function (err) { note.textContent = what + ': ' + ((err && err.message) || err); note.className = 'toast bad'; }; });
        var f = box('foot'); f.appendChild(note);
        header('NOVULON', 'Money', closeMenu, menu);
        add(menu, body, f);
    }

    // ---------------- right-click on the game's Relationships cards ----------------
    // While the game's Relationships panel is open, an invisible spot sits over each card. Right-click opens
    // a small menu; left clicks and the wheel are handed straight back to the game.
    var spotsBox = $('card-spots'), relMenu = $('rel-menu');
    var SPOTS = [], cards = [], tileRef = null, relPanelOpen = false, partners = {}, partnersAt = 0, ages = {};
    for (var si = 0; si < 16; si++) {
        (function () {
            var s = box('card-spot');
            s.style.display = 'none';
            s.addEventListener('mousedown', function (e) {
                var c = s._card;
                if (!c) { return; }
                if (e.button === 2) { e.preventDefault(); openRelMenu(c, e.clientX, e.clientY); return; }
                if (e.button === 0) {
                    // hand the click back: stop taking the mouse, then click the same spot for real
                    var x = e.clientX, y = e.clientY;
                    shell.suspend(450);
                    run('ui.click', { X: x, Y: y }).catch(function () {});
                }
            });
            s.addEventListener('contextmenu', function (e) { e.preventDefault(); });
            s.addEventListener('wheel', function (e) {
                if (tileRef) { run('ui.scroll', { ref: tileRef, To: 'offset', Delta: e.deltaY * 0.8 }).catch(function () {}); }
            });
            spotsBox.appendChild(s);
            SPOTS.push(s);
            shell.addArea(s);
        })();
    }

    function relPartners() {
        if (Date.now() - partnersAt < 4000) { return Promise.resolve(partners); }
        return run('entity.get_possessed', {}).then(function (p) {
            state.me = p && p.entity_id;
            return run('relationships.list', { owner_id: String(state.me), min_value: -100 });
        }).then(function (d) {
            partners = {};
            ((d && d.relationships) || []).forEach(function (r) {
                partners[(r.first_name + ' ' + r.last_name).trim().toLowerCase()] = r;
            });
            partnersAt = Date.now();
            return partners;
        });
    }
    function pollCards() {
        return hudPanels().then(function (btns) {
            relPanelOpen = btns.some(function (b) { return /RelationshipList/.test(b.ref); });
            if (!relPanelOpen) { cards = []; return; }
            return run('ui.find', { Window: 'Hud', Name: 'RelationshipListEntry', Limit: 60 }).then(function (list) {
                cards = (Array.isArray(list) ? list : []).filter(function (c) { return c.rect && c.text; });
                if (cards[0]) { tileRef = cards[0].ref.split('/').slice(0, -1).join('/'); }
            });
        }).catch(function () { cards = []; }).then(function () {
            SPOTS.forEach(function (s, i) {
                var c = cards[i];
                s._card = c || null;
                if (c) { shell.place(s, shell.toView(c.rect)); show(s, true); } else { show(s, false); }
            });
            if (!relPanelOpen && isOpen(relMenu)) { closeRelMenu(); }
            shell.settle();
        });
    }
    setInterval(pollCards, 600);

    function closeRelMenu() { show(relMenu, false); shell.settle(); }
    function openRelMenu(card, cx, cy) {
        relMenu.innerHTML = '';
        var name = card.text;
        var w = 300, h = 360;
        var x = Math.max(8, cx - w - 14), y = Math.max(8, Math.min(window.innerHeight - h - 8, cy - 40));
        shell.place(relMenu, { x: x, y: y, w: w, h: h });
        var head = box('head'), titles = box('head-titles');
        add(titles, txt('kicker', 'RELATIONSHIP'), txt('title', name));
        add(head, face(name), gap(), titles, xButton(closeRelMenu));
        var body = box('rm-body'), stats = box('rm-stats'), note = txt('toast', '');
        add(body, stats);
        relMenu.appendChild(box('topline'));
        add(relMenu, head, body);
        show(relMenu, true);
        shell.settle();

        relPartners().then(function (all) {
            var r = all[name.trim().toLowerCase()];
            if (!r) { add(body, txt('empty', 'This person isn\'t in the list yet. Try again in a moment.')); return; }
            var id = r.target_id, st = r.stats || {};
            REL.forEach(function (k) {
                if (!st[k.id] || (k.id === 'Family' && !r.is_family)) { return; }
                var s = box('rm-stat'), dot = box('rel-dot');
                dot.style.background = k.color;
                add(s, dot, txt('rm-stat-text', k.name + ' ' + Math.round(st[k.id].value)));
                stats.appendChild(s);
            });
            var ageP = ages[id] ? Promise.resolve(ages[id])
                : run('entity.get_character_info', { entity_id: String(id) }).then(function (i) { ages[id] = i && i.growth_step; return ages[id]; });
            var meP = run('entity.get_character_info', { entity_id: String(state.me) }).then(function (i) { return i && i.growth_step; });
            Promise.all([ageP, meP]).then(function (ag) {
                var lovable = nv.isGrown(ag[0]) && nv.isGrown(ag[1]);   // love only between adults
                function item(text, sub, cls, fn) {
                    var it = box('rm-item' + (cls ? ' ' + cls : ''));
                    add(it, txt('rm-item-text', text), txt('rm-item-sub', sub));
                    it.addEventListener('click', fn);
                    body.appendChild(it);
                }
                function setStats(values, done) {
                    note.textContent = '';
                    Promise.all(Object.keys(values).map(function (k) {
                        return run('relationships.set_value_between', { owner_id: String(state.me), target_id: String(id), relationship_id: k, Value: values[k] });
                    })).then(function () { partnersAt = 0; note.className = 'toast'; note.textContent = done; })
                      .catch(function (e) { note.className = 'toast bad'; note.textContent = (e && e.message) || String(e); });
                }
                var maxAll = { Friendship: 100, Business: 100 };
                if (lovable) { maxAll.Romance = 100; }
                if (r.is_family) { maxAll.Family = 100; }
                item('Max everything', lovable ? 'love too' : '', '', function () { setStats(maxAll, 'Everything maxed with ' + name + '.'); });
                item('Best friends', 'friendship 100', '', function () { setStats({ Friendship: 100 }, name + ' is a best friend now.'); });
                if (lovable) { item('Soulmates', 'love and friendship 100', '', function () { setStats({ Romance: 100, Friendship: 100 }, 'Soulmates with ' + name + '.'); }); }
                var zero = { Friendship: 0, Business: 0 };
                if (lovable) { zero.Romance = 0; }       // never touch love between a pair the game doesn't allow it for
                item('Strangers', 'back to 0', '', function () { setStats(zero, name + ' is a stranger again.'); });
                body.appendChild(box('rm-line'));
                item('Delete relationship', 'removes them from the list', 'danger', function () { askDelete(); });
                body.appendChild(note);

                function askDelete() {
                    Array.prototype.slice.call(body.children).forEach(function (c) { if (c !== note) { body.removeChild(c); } });
                    body.insertBefore(txt('rm-ask', 'Delete the relationship with ' + name + '? Both of them forget each other.'), note);
                    var row = box('row');
                    add(row, button('Delete', 'danger grow', function () { doDelete(); }), gap(), button('Keep', 'glass grow', closeRelMenu));
                    body.insertBefore(row, note);
                }
                function doDelete() {
                    note.className = 'toast'; note.textContent = 'Deleting...';
                    // zero each stat on its own (the all-stats form was running when the game crashed); the game
                    // drops a relationship that sits at zero for a while, and the Lua part, when on, deletes it now
                    Promise.all(Object.keys(zero).map(function (k) {
                        return run('relationships.set_value_between', { owner_id: String(state.me), target_id: String(id), relationship_id: k, Value: 0 }).catch(function () {});
                    })).then(function () { return LUA_ON ? luaCall('op=forget;pid=' + state.me + ';target=' + id) : null; })
                        .then(function (res) {
                            partnersAt = 0;
                            note.className = 'toast';
                            note.textContent = res && res.ok ? 'Relationship with ' + name + ' deleted.'
                                                             : 'Set to zero. The game removes ' + name + ' after a short wait.';
                            setTimeout(closeRelMenu, 1800);
                        });
                }
            }).catch(fail('Relationship'));
        }).catch(function (e) { add(body, txt('empty', (e && e.message) || String(e))); });
    }

    // ---------------- the Lua part (relationship delete) ----------------
    // The window writes a command file; lua\B1\Main.lua hands it to the simulation side, which answers
    // with the event lua_message.sc_done.
    var luaSeq = Date.now() % 1000000, luaWait = {};
    function luaCall(cmd) {
        luaSeq += 1;
        var seq = String(luaSeq);
        return new Promise(function (resolve) {
            luaWait[seq] = resolve;
            run('uimod.cfg_save', { mod_id: wf.MOD_ID, Section: 'bus', Key: 'cmd', Value: cmd + ';seq=' + seq }).catch(function () {});
            setTimeout(function () { if (luaWait[seq]) { delete luaWait[seq]; resolve(null); } }, 4000);
        });
    }
    try {
        inzoi.event.on('lua_message.sc_done', function (d) {
            var seq = d && String(d.seq), fn = luaWait[seq];
            nv.log('lua ' + (d && d.op) + ' ok=' + (d && d.ok) + (d && d.why ? ' ' + d.why : '') + (d && d.rel != null ? ' rel=' + d.rel : ''));
            if (fn) { delete luaWait[seq]; fn(d); }
        });
    } catch (e) { nv.log('lua events: ' + e); }
    // The Lua part stays off until the crash on 2026-09-28 04:30 is understood (a Lua call hit a null pointer
    // while both Novulon Lua mods were mounted). Without it, Delete zeroes the relationship and the game
    // removes it after its own wait.
    var LUA_ON = false;
    if (LUA_ON) {
        run('luamod.remount', { mod_id: wf.MOD_ID }).catch(function () { return run('luamod.mount', { mod_id: wf.MOD_ID }); })
            .catch(function (e) { nv.log('lua mount: ' + ((e && e.message) || e)); });
    }

    // ---------------- start ----------------
    shell.addArea(nbtn, true);
    shell.addArea(spot);
    shell.addArea(menu);
    shell.addArea(win);
    shell.addArea(relMenu);
    shell.addArea(chooser);
    run('ui.list_windows', {}).then(function (d) {
        if (d && d.screen) { shell.screenSize.w = d.screen[0]; shell.screenSize.h = d.screen[1]; }
    }).catch(function () {}).then(layout);
    setInterval(layout, 3000);
    window.addEventListener('resize', layout);

    // Test hook: a "remote" cfg value (written from outside with uimod.cfg_save) opens pages for screenshots.
    var lastRemote = null;
    setInterval(function () {
        run('uimod.cfg_load', { mod_id: wf.MOD_ID, Section: 'ui/StatCheats/saved', Key: 'remote' }).then(function (d) {
            var v = d && (d.value != null ? d.value : d.Value);
            if (v == null || v === lastRemote) { return; }
            var first = lastRemote === null;
            lastRemote = v;
            if (first) { return; }            // ignore whatever was there at load time
            var cmd = String(v).split('|')[0];
            if (cmd === 'open') { openWin(); }
            else if (cmd === 'close') { closeWin(); closeMenu(); }
            else if (cmd.indexOf('tab:') === 0) { state.tab = cmd.slice(4); if (!isOpen(win)) { openWin(); } else { drawTab(); } }
            else if (cmd === 'pick') { openPicker(null); }
            else if (cmd === 'chooser') { openChooser(); }
            else if (cmd === 'menu') { closeWin(); buildMenu(); placeWindows(); show(menu, true); shell.settle(); }
        }).catch(function () {});
    }, 1500);
})();
