-- Novulon's AI Remade: game-thread relay. The window writes a command file; this passes it to the
-- simulation side through the controlled zoi (simulation Lua can't read files itself).
local M = {}
local MOD = 'NovulonAIRemade_6U5ANM'
local frame, last = 0, nil

local function read()
    local ok, _, data = inzoi.cli.execute('uimod.cfg_load mod_id=' .. MOD .. ' Section=bus Key=cmd')
    if not ok or not data then return nil end
    local s = tostring(data)
    return s:match('"value"%s*:%s*"(.-)"') or s
end

function M.on_tick()
    frame = frame + 1
    if frame % 12 ~= 0 then return end
    local v = read()
    if v and v ~= last then
        last = v
        local pid = v:match('pid=(%d+)')
        if pid then inzoi.message.send_to_sim(tonumber(pid), 'nv_cmd', v) end
    end
end

function M.on_begin() end
function M.on_end() end

return M