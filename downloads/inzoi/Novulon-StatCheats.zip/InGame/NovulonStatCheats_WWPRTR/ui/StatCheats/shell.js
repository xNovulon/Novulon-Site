/**
 * shell.js -- input and placement for a full-screen overlay view with several small hot areas
 * (the N button, the money spot, the window). Replaces the scaffold's single-window window.js.
 *
 * The game only sends clicks to this view inside the rect reported with setContentRect, so the rect
 * follows whichever hot area the mouse is over. Native click events are unreliable in cohtml, so a
 * click is synthesized on mouseup (same trick as the scaffold's window.js).
 */
(function () {
    'use strict';

    var MOD_ID = window.__uimod_mod_id || 'NovulonStatCheats_WWPRTR';
    var APP_NAME = 'StatCheats';

    function cli(cmd, params) { return inzoi.cli.execute(cmd, params || {}); }

    function hover(on) {
        try { if (window.inzoi && inzoi.view && inzoi.view.hover) { inzoi.view.hover(!!on); return; } } catch (e) {}
        try {
            engine.call('_uimod_request', JSON.stringify({ type: 'view', action: 'hover', over: !!on, promiseId: 0 }));
        } catch (e2) {}
    }
    function reportRect(r) {
        try { if (window.inzoi && inzoi.view && inzoi.view.setContentRect) { inzoi.view.setContentRect(r.x, r.y, r.w, r.h); } } catch (e) {}
    }

    // ---- hot areas ----------------------------------------------------------
    var areas = [];      // elements that take the mouse, topmost last
    var current = null;
    var home = null;     // area whose rect is reported while the mouse is elsewhere

    function shown(elm) {
        if (!elm || !elm.isConnected) { return false; }
        for (var n = elm; n && n !== document.body; n = n.parentElement) {
            if (n.style && n.style.display === 'none') { return false; }
            if (n.classList && n.classList.contains('hidden')) { return false; }
        }
        return true;
    }
    function rectOf(elm) {
        var b = elm.getBoundingClientRect();
        return { x: Math.floor(b.left), y: Math.floor(b.top), w: Math.ceil(b.width), h: Math.ceil(b.height) };
    }
    function areaAt(x, y) {
        for (var i = areas.length - 1; i >= 0; i--) {
            var a = areas[i];
            if (!shown(a)) { continue; }
            var b = a.getBoundingClientRect();
            if (x >= b.left && x < b.right && y >= b.top && y < b.bottom) { return a; }
        }
        return null;
    }
    function settle() {
        // after something opens or closes: point the rect at a visible area
        if (current && shown(current)) { reportRect(rectOf(current)); return; }
        current = null;
        hover(false);
        if (home && shown(home)) { reportRect(rectOf(home)); }
        else { reportRect({ x: 0, y: 0, w: 1, h: 1 }); }
    }
    document.addEventListener('mousemove', function (e) {
        var a = areaAt(e.clientX, e.clientY);
        if (a !== current) {
            current = a;
            if (a) { reportRect(rectOf(a)); hover(true); } else { hover(false); }
        }
    });

    function addArea(elm, isHome) {
        areas.push(elm);
        if (isHome) { home = elm; }
        elm.addEventListener('wheel', function (e) { e.stopPropagation(); }, { passive: false });
        settle();
    }

    // ---- reliable clicks ---------------------------------------------------------
    var downTarget = null, guard = false;
    document.addEventListener('mousedown', function (e) { if (e.button === 0) { downTarget = e.target; } }, true);
    document.addEventListener('mouseup', function (e) {
        if (e.button !== 0) { return; }
        var dt = downTarget; downTarget = null;
        if (!dt) { return; }
        var up = e.target;
        var same = up === dt || (dt.contains && dt.contains(up)) || (up.contains && up.contains(dt));
        if (!same) { return; }
        guard = true;
        var evt;
        try { evt = new MouseEvent('click', { bubbles: true, cancelable: true }); }
        catch (err) { evt = document.createEvent('MouseEvents'); evt.initEvent('click', true, true); }
        evt._nvSynthetic = true;
        up.dispatchEvent(evt);
        setTimeout(function () { guard = false; }, 0);
    }, true);
    document.addEventListener('click', function (e) {
        if (e._nvSynthetic) { return; }
        if (guard) { e.stopImmediatePropagation(); e.preventDefault(); }
    }, true);

    // ---- screen <-> view pixels -----------------------------------------------------
    // HUD rects from ui.find are in screen pixels; this view may be laid out at another size.
    var screenSize = { w: 1920, h: 1200 };
    function toView(r) {
        var sx = window.innerWidth / screenSize.w, sy = window.innerHeight / screenSize.h;
        return { x: r[0] * sx, y: r[1] * sy, w: r[2] * sx, h: r[3] * sy };
    }
    function place(elm, r) {
        elm.style.left = Math.round(r.x) + 'px';
        elm.style.top = Math.round(r.y) + 'px';
        if (r.w != null) { elm.style.width = Math.round(r.w) + 'px'; }
        if (r.h != null) { elm.style.height = Math.round(r.h) + 'px'; }
    }

    window.wf = { cli: cli, MOD_ID: MOD_ID, APP_NAME: APP_NAME };
    window.shell = { addArea: addArea, settle: settle, toView: toView, place: place, screenSize: screenSize, hover: hover };
})();
