/**
 * nv.js -- small helpers shared by Novulon's mods (one copy per app folder).
 * Loaded after window.js, before app.js.
 */
(function () {
    'use strict';

    // Run a game command and hand back its data (parsed JSON when the game sends text).
    function run(cmd, params) {
        return Promise.resolve(wf.cli(cmd, params || {})).then(function (res) {
            if (res == null) { throw new Error(cmd + ': no answer'); }
            if (res.success === false) { throw new Error((res.message || cmd + ' failed').toString()); }
            var d = res.data;
            if (typeof d === 'string') { d = parseLoose(d); }
            if (d == null && typeof res.message === 'string') { d = parseLoose(res.message); }
            if (d == null && typeof res === 'object' && !('success' in res)) { d = res; }
            return d;
        });
    }

    // JSON.parse, or the JSON that follows a one-line summary ("3 match(es).\n[...]").
    function parseLoose(text) {
        if (typeof text !== 'string') { return text; }
        try { return JSON.parse(text); } catch (e) {}
        var i = text.search(/[\[{]/);
        if (i > 0) { try { return JSON.parse(text.slice(i)); } catch (e2) {} }
        return null;
    }

    // Last few problems, saved next to the window settings so they can be read from disk.
    var logLines = [];
    function log(msg) {
        var d = new Date();
        function p(n) { return (n < 10 ? '0' : '') + n; }
        var stamp = d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' +
                    p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
        logLines.push(stamp + ' ' + msg);
        if (logLines.length > 60) { logLines.shift(); }
        try {
            wf.cli('uimod.cfg_save', { mod_id: wf.MOD_ID, section: 'ui/' + wf.APP_NAME + '/saved',
                                       key: 'log', value: logLines.join('\n') });
        } catch (e) {}
    }

    function el(tag, cls, text) {
        var e = document.createElement(tag);
        if (cls) { e.className = cls; }
        if (text != null) { e.textContent = text; }
        return e;
    }

    function fmtMoney(n) {
        n = Math.round(Number(n) || 0);
        var s = String(Math.abs(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        return (n < 0 ? '-' : '') + s;
    }

    // Money lives on the household's currency component; "mew" is the main wallet.
    function household() {
        return run('household.get_members', {}).then(function (d) { return d; });
    }
    function getMoney() {
        return household().then(function (h) {
            return run('entity.reflect', { entity_id: String(h.household_id), Component: 'Currency' });
        }).then(function (c) {
            var map = (c && c.currencyMap) || {};
            return Number(map.mew || 0);
        });
    }
    function addMoney(amount) {
        amount = Math.round(amount);
        if (!amount) { return Promise.resolve(); }
        return run('currency.add_money', { Amount: amount });
    }
    function setMoney(target) {
        return getMoney().then(function (now) { return addMoney(Math.round(target) - now); });
    }

    // Young adults ("Youth"), adults and elders only.
    var GROWN = { Youth: 1, YoungAdult: 1, Adult: 1, Old: 1, Elder: 1, Elderly: 1 };
    function isGrown(ageGroup) { return !!GROWN[ageGroup]; }

    window.nv = { run: run, log: log, el: el, fmtMoney: fmtMoney, household: household,
                  getMoney: getMoney, addMoney: addMoney, setMoney: setMoney, isGrown: isGrown,
                  parseLoose: parseLoose };
})();
