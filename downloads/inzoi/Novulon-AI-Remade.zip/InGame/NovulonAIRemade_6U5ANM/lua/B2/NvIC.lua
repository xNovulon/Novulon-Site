-- Novulon's AI Remade: keeps a handle to every zoi's Interaction component.
local S = require('NvShared')
local M = {}

function M.on_begin(self, comp)
    local id = S.ownerId(comp)
    if id then S.ic[id] = comp; self.id = id end
end

function M.on_end(self, comp)
    if self.id and S.ic[self.id] == comp then S.ic[self.id] = nil end
end

return M